<?php
include("dbconnect.php");
session_start();
extract($_POST);
error_reporting(0);
$un = $_SESSION['un'];
$rtu=mysqli_query($conn,"select * from student where regno='$un'");
$gh=mysqli_fetch_array($rtu);
$nid=$gh['id'];
$qid = $_REQUEST['id'];
$qry = mysqli_query($conn, "select * from exam where id='$qid'");
$r = mysqli_fetch_array($qry);
$qname = $r['subject'];
 
 
 
 
 
 
  $qry5=mysqli_query($conn,"select * from question1 where subject='$qname'");

  echo  $num5=mysqli_num_rows($qry5);

if (isset($_POST['btn'])) {
    $i = $_REQUEST['an'] - 1;

    $totalScore = 0;


   

    // Initialize $qs as an array
   
for ($j = 1; $j <=$i; $j++) {
     $an = $_REQUEST["an$j"];
     $q = $_REQUEST["q$j"];
    $qs = $_REQUEST["qs$j"];

        if ($an == $q) {
           echo $totalScore += 1;
        }

        // Removed the unnecessary lines setting individual question variables
    }

    $id_query = mysqli_query($conn, "select max(id) from result");
    $max_row = mysqli_fetch_array($id_query);
    $id = $max_row['max(id)'] + 1;

    $result_query = mysqli_query($conn, "insert into result(id, nid, name, test, tqus, result) values('$id','$un','$un','$qname','$i','$totalScore')");

    $questions_query = mysqli_query($conn, "INSERT INTO uques VALUES ('$id', '$un', '$qs1', '$qs2', '$qs3', '$qs4', '$qs5', '$qs6', '$qs7', '$qs8', '$qs9', '$qs10',
                                          '$qs11', '$qs12', '$qs13', '$qs14', '$qs15', '$qs16', '$qs17', '$qs18', '$qs19', '$qs20',
                                          '$qs21', '$qs22', '$qs23', '$qs24', '$qs25', '$qs26', '$qs27', '$qs28', '$qs29', '$qs30',
                                          '$qs31', '$qs32', '$qs33', '$qs34', '$qs35', '$qs36', '$qs37', '$qs38', '$qs39', '$qs40',
                                          '$qs41', '$qs42', '$qs43', '$qs44', '$qs45', '$qs46', '$qs47', '$qs48', '$qs49', '$qs50',
                                        '$q1', '$q2', '$q3', '$q4', '$q5', '$q6', '$q7', '$q8', '$q9', '$q10',
                                        '$q11', '$q12', '$q13', '$q14', '$q15', '$q16', '$q17', '$q18', '$q19', '$q20',
                                        '$q21', '$q22', '$q23', '$q24', '$q25', '$q26', '$q27', '$q28', '$q29', '$q30',
                                        '$q31', '$q32', '$q33', '$q34', '$q35', '$q36', '$q37', '$q38', '$q39', '$q40',
                                        '$q41', '$q42', '$q43', '$q44', '$q45', '$q46', '$q47', '$q48', '$q49', '$q50')");

    if ($result_query && $questions_query) {
    header('location:result1.php?id=' . $id);
    exit(); // Ensure no further output after redirect
  } else {
    // Handle query errors appropriately
    echo "Error: Failed to insert data."; // Replace with proper error handling
  }
}
?>


<!doctype html>
<html class="no-js" lang="zxx">

<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>Edura -  Courses & Education HTML Template - Home One</title>
    <meta name="author" content="themeholy">
    <meta name="description" content="Edura -  Courses & Education HTML Template">
    <meta name="keywords" content="Edura -  Courses & Education HTML Template">
    <meta name="robots" content="INDEX,FOLLOW">
    <meta name="viewport" content="width=device-width,initial-scale=1,shrink-to-fit=no">
    <link rel="apple-touch-icon" sizes="57x57" href="assets/img/favicons/apple-icon-57x57.png">
    <link rel="apple-touch-icon" sizes="60x60" href="assets/img/favicons/apple-icon-60x60.png">
    <link rel="apple-touch-icon" sizes="72x72" href="assets/img/favicons/apple-icon-72x72.png">
    <link rel="apple-touch-icon" sizes="76x76" href="assets/img/favicons/apple-icon-76x76.png">
    <link rel="apple-touch-icon" sizes="114x114" href="assets/img/favicons/apple-icon-114x114.png">
    <link rel="apple-touch-icon" sizes="120x120" href="assets/img/favicons/apple-icon-120x120.png">
    <link rel="apple-touch-icon" sizes="144x144" href="assets/img/favicons/apple-icon-144x144.png">
    <link rel="apple-touch-icon" sizes="152x152" href="assets/img/favicons/apple-icon-152x152.png">
    <link rel="apple-touch-icon" sizes="180x180" href="assets/img/favicons/apple-icon-180x180.png">
    <link rel="icon" type="image/png" sizes="192x192" href="assets/img/favicons/android-icon-192x192.png">
    <link rel="icon" type="image/png" sizes="32x32" href="assets/img/favicons/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="96x96" href="assets/img/favicons/favicon-96x96.png">
    <link rel="icon" type="image/png" sizes="16x16" href="assets/img/favicons/favicon-16x16.png">
    <link rel="manifest" href="assets/img/favicons/manifest.json">
    <meta name="msapplication-TileColor" content="#ffffff">
    <meta name="msapplication-TileImage" content="assets/img/favicons/ms-icon-144x144.png">
    <meta name="theme-color" content="#ffffff">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Baloo+2:wght@400;500;600;700;800&family=Jost:wght@300;400;500;600;700;800;900&family=Roboto:wght@100;300;400;500;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/app.min.css">
    <link rel="stylesheet" href="assets/css/fontawesome.min.css">
    <link rel="stylesheet" href="assets/css/style.css">
		<script src="https://kit.fontawesome.com/1fb451dce7.js" crossorigin="anonymous"></script>
</head>

<body>
    <div class="preloader"><button class="th-btn style3 preloaderCls">Cancel Preloader</button>
        <div class="preloader-inner"><span class="loader"></span></div>
    </div>
		<img src="download.png" style="width:100px;height:100px;border-radius:50%;position:absolute;z-index:100;top:20px;left:50px;border:5px solid white;">
    <div class="sidemenu-wrapper d-none d-lg-block">
        <div class="sidemenu-content"><button class="closeButton sideMenuCls"><i class="far fa-times"></i></button>
            <div class="widget woocommerce widget_shopping_cart">
                <h3 class="widget_title">Shopping cart</h3>
                <div class="widget_shopping_cart_content">
                    <ul class="woocommerce-mini-cart cart_list product_list_widget">
                        <li class="woocommerce-mini-cart-item mini_cart_item"><a href="#" class="remove remove_from_cart_button"><i class="far fa-times"></i></a> <a href="#"><img src="assets/img/product/product_thumb_1_1.jpg" alt="Cart Image">Plastic Book Bags</a> <span class="quantity">1 � <span class="woocommerce-Price-amount amount"><span class="woocommerce-Price-currencySymbol">$</span>940.00</span>
                            </span>
                        </li>
                        <li class="woocommerce-mini-cart-item mini_cart_item"><a href="#" class="remove remove_from_cart_button"><i class="far fa-times"></i></a> <a href="#"><img src="assets/img/product/product_thumb_1_2.jpg" alt="Cart Image">The Genie Mind</a> <span class="quantity">1 � <span class="woocommerce-Price-amount amount"><span class="woocommerce-Price-currencySymbol">$</span>899.00</span>
                            </span>
                        </li>
                        <li class="woocommerce-mini-cart-item mini_cart_item"><a href="#" class="remove remove_from_cart_button"><i class="far fa-times"></i></a> <a href="#"><img src="assets/img/product/product_thumb_1_3.jpg" alt="Cart Image">The Energy Book</a> <span class="quantity">1 � <span class="woocommerce-Price-amount amount"><span class="woocommerce-Price-currencySymbol">$</span>756.00</span>
                            </span>
                        </li>
                        <li class="woocommerce-mini-cart-item mini_cart_item"><a href="#" class="remove remove_from_cart_button"><i class="far fa-times"></i></a> <a href="#"><img src="assets/img/product/product_thumb_1_4.jpg" alt="Cart Image">Pencil Bag</a> <span class="quantity">1 � <span class="woocommerce-Price-amount amount"><span class="woocommerce-Price-currencySymbol">$</span>723.00</span>
                            </span>
                        </li>
                        <li class="woocommerce-mini-cart-item mini_cart_item"><a href="#" class="remove remove_from_cart_button"><i class="far fa-times"></i></a> <a href="#"><img src="assets/img/product/product_thumb_1_5.jpg" alt="Cart Image">Sharpner</a> <span class="quantity">1 � <span class="woocommerce-Price-amount amount"><span class="woocommerce-Price-currencySymbol">$</span>1080.00</span>
                            </span>
                        </li>
                    </ul>
                    <p class="woocommerce-mini-cart__total total"><strong>Subtotal:</strong> <span class="woocommerce-Price-amount amount"><span class="woocommerce-Price-currencySymbol">$</span>4398.00</span>
                    </p>
                    <p class="woocommerce-mini-cart__buttons buttons"><a href="cart.html" class="th-btn wc-forward">View cart</a> <a href="checkout.html" class="th-btn checkout wc-forward">Checkout</a></p>
                </div>
            </div>
        </div>
    </div>
    <div class="popup-search-box d-none d-lg-block"><button class="searchClose"><i class="fal fa-times"></i></button>
        <form action="#"><input type="text" placeholder="What are you looking for?"> <button type="submit"><i class="fal fa-search"></i></button></form>
    </div>
    <div class="th-menu-wrapper">
        <div class="th-menu-area text-center"><button class="th-menu-toggle"><i class="fal fa-times"></i></button>
            <div class="mobile-logo"><a href="index.html"><img src="assets/img/logo.svg" alt="Edura"></a></div>
            <div class="th-mobile-menu">
                <ul>
                    <li class="menu-item-has-children"><a href="index.html">Home</a>
                     
                    <li class="menu-item-has-children"><a href="#">Blog</a>
                        <ul class="sub-menu">
                            <li><a href="blog.html">Blog</a></li>
                            <li><a href="blog-details.html">Blog Details</a></li>
                        </ul>
                    </li>
                    <li><a href="contact.html">Contact</a></li>
                </ul>
            </div>
        </div>
    </div>
    <header class="th-header header-layout1 onepage-nav">
        <div class="header-top">
            <div class="container">
                <div class="row justify-content-center justify-content-lg-between align-items-center gy-2">
                    <div class="col-auto d-none d-lg-block">
                        <div class="header-links">
                            <ul>
                                <li><i class="far fa-phone"></i><a href="tel:+11156456825">+91 9788349333</a></li>
                                <li class="d-none d-xl-inline-block"><i class="far fa-envelope"></i><a href="mailto:info@Valluvar College of Science and Management.com">info@Valluvar College of Science and Management.com</a></li>
                                <li><i class="far fa-clock"></i>Mon - Sat: 8:00 - 15:00</li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-auto">
                        <div class="header-links header-right">
                            <ul>
                                <li>
                                    <div class="header-social"><span class="social-title">Follow Us:</span> <a href="https://www.facebook.com/"><i class="fab fa-facebook-f"></i></a> <a href="https://www.twitter.com/"><i class="fab fa-twitter"></i></a> <a href="https://www.linkedin.com/"><i class="fab fa-linkedin-in"></i></a>                                        <a href="https://www.youtube.com/"><i class="fab fa-youtube"></i></a> <a href="https://www.instagram.com/"><i class="fab fa-skype"></i></a></div>
                                </li>
                              
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="sticky-wrapper">
            <div class="menu-area">
                <div class="container">
                    <div class="row align-items-center justify-content-between">
                        <div class="col-auto">
                            <div class="header-logo"><h3 style="color:#0d5ef4">visual learning and task management system</h3></div>
                        </div>
                        <div class="col-auto">
                            <div class="row">
                                <div class="col-auto">
                                    <nav class="main-menu d-none d-lg-inline-block">
                                        <ul>
                                              <li ><a href="stuhome.php">Home</a>
											 <li ><a href="sclass.php">View Class</a>
											   <li ><a href="dmaterial.php"> Material</a>
														       <li ><a href="dassign.php">View Assignment</a>
															   <li ><a href="uploadassign.php">Upload Assignment</a>
															    <li ><a href="sreport.php">Report</a>
																  <li ><a href="index.php">Logout</a> </li>
														  
                                               </li>
											   </ul>
                                    </nav><button type="button" class="th-menu-toggle d-block d-lg-none"><i class="far fa-bars"></i></button></div>
                          
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </header>
    <div class="th-hero-wrapper hero-1" id="hero">
        <div class="hero-slider-1 th-carousel" data-fade="true" data-slide-show="1" data-md-slide-show="1" data-dots="true">
            <div class="th-hero-slide">
                <div class="th-hero-bg" data-overlay="title" data-opacity="8" data-bg-src="assets/img/hero/hero_bg_1_1.jpg"></div>
                <div class="container">
                    <div class="row align-items-center justify-content-center">
                        <div class="col-md-6">
                            <div class="hero-style1"><span class="hero-subtitle" data-ani="slideinleft" data-ani-delay="0.1s"><span></span> LEARN FROM TODAY</span>
                                <h1 class="hero-title text-white" data-ani="slideinleft" data-ani-delay="0.4s">Education Is Create Better <span class="text-theme">Future.</span></h1>
                                <p class="hero-text" data-ani="slideinleft" data-ani-delay="0.6s">Education can be thought of as the transmission of the values and accumulated knowledge of a society. In this sense, it is equivalent.</p>
                            </div>
                        </div>
                        <div class="col-md-6 text-lg-end text-center">
                            <div class="hero-img1"><img src="assets/img/hero/hero_thumb_1_1.jpg" alt="hero"></div>
                        </div>
                    </div>
                </div>
                <div class="hero-shape shape1"><img src="assets/img/hero/shape_1_1.png" alt="shape"></div>
                <div class="hero-shape shape2"><img src="assets/img/hero/shape_1_2.png" alt="shape"></div>
                <div class="hero-shape shape3"></div>
                <div class="hero-shape shape4 shape-mockup jump-reverse" data-right="3%" data-bottom="7%"><img src="assets/img/hero/shape_1_3.png" alt="shape"></div>
                <div class="hero-shape shape5 shape-mockup jump-reverse" data-left="0" data-bottom="0"><img src="assets/img/hero/shape_1_4.png" alt="shape"></div>
            </div>
            <div class="th-hero-slide">
                <div class="th-hero-bg" data-overlay="title" data-opacity="8" data-bg-src="assets/img/hero/hero_bg_1_2.jpg"></div>
                <div class="container">
                    <div class="row align-items-center justify-content-center">
                        <div class="col-md-6">
                            <div class="hero-style1"><span class="hero-subtitle" data-ani="slideinleft" data-ani-delay="0.1s"><span></span> LEARN FROM TODAY</span>
                                <h1 class="hero-title text-white" data-ani="slideinleft" data-ani-delay="0.4s">Edura Leads To A Brighter <span class="text-theme">Future.</span></h1>
                                <p class="hero-text" data-ani="slideinleft" data-ani-delay="0.6s">Education can be thought of as the transmission of a societys values and accumulated knowledge. In this sense, it is equivalent.</p>
                            </div>
                        </div>
                        <div class="col-md-6 text-lg-end text-center">
                            <div class="hero-img1"><img src="assets/img/hero/hero_thumb_1_2.jpg" alt="hero"></div>
                        </div>
                    </div>
                </div>
                <div class="hero-shape shape1"><img src="assets/img/hero/shape_1_1.png" alt="shape"></div>
                <div class="hero-shape shape2"><img src="assets/img/hero/shape_1_2.png" alt="shape"></div>
                <div class="hero-shape shape3"></div>
                <div class="hero-shape shape4 shape-mockup jump-reverse" data-right="3%" data-bottom="7%"><img src="assets/img/hero/shape_1_3.png" alt="shape"></div>
                <div class="hero-shape shape5 shape-mockup jump-reverse" data-left="0" data-bottom="0"><img src="assets/img/hero/shape_1_4.png" alt="shape"></div>
            </div>
            <div class="th-hero-slide">
                <div class="th-hero-bg" data-overlay="title" data-opacity="8" data-bg-src="assets/img/hero/hero_bg_1_3.jpg"></div>
                <div class="container">
                    <div class="row align-items-center justify-content-center">
                        <div class="col-md-6">
                            <div class="hero-style1"><span class="hero-subtitle" data-ani="slideinleft" data-ani-delay="0.1s"><span></span> LEARN FROM TODAY</span>
                                <h1 class="hero-title text-white" data-ani="slideinleft" data-ani-delay="0.4s">The Worlds Best  Education <span class="text-theme">Institute.</span></h1>
                                <p class="hero-text" data-ani="slideinleft" data-ani-delay="0.6s">Education can be thought of as the transmission of the values and accumulated knowledge of a society. In this sense, it is equivalent.</p>
                            </div>
                        </div>
                        <div class="col-md-6 text-lg-end text-center">
                            <div class="hero-img1"><img src="assets/img/hero/hero_thumb_1_3.jpg" alt="hero"></div>
                        </div>
                    </div>
                </div>
                <div class="hero-shape shape1"><img src="assets/img/hero/shape_1_1.png" alt="shape"></div>
                <div class="hero-shape shape2"><img src="assets/img/hero/shape_1_2.png" alt="shape"></div>
                <div class="hero-shape shape3"></div>
                <div class="hero-shape shape4 shape-mockup jump-reverse" data-right="3%" data-bottom="7%"><img src="assets/img/hero/shape_1_3.png" alt="shape"></div>
                <div class="hero-shape shape5 shape-mockup jump-reverse" data-left="0" data-bottom="0"><img src="assets/img/hero/shape_1_4.png" alt="shape"></div>
            </div>
        </div>
    </div>
   
   
   
<br /><br /><br /><br /><br /><br /><br /><br /><br /><br />
<form id="form1" name="form1" method="post" action="">
  <table width="80%" border="0">
    <tr>
      <td width="20%"><div align="right"><span class="style3">Time Left: </span></div></td>
      <td width="14%" bgcolor="#009CD5">
        <span class="style1">
          <span class="style2">
            <label id="minutes"><strong><?php echo $num5; ?></strong></label>
            <strong>:</strong>
            <label id="seconds">59</label>
          </span>
          <strong>
            <script
 
type="text/javascript">

 var minutesLabel = document.getElementById("minutes");
var secondsLabel = document.getElementById("seconds");
var totalSeconds = <?php echo $num5 * 60; ?>; // Ensure the correct conversion from minutes to seconds

console.log("Initial value of totalSeconds:", totalSeconds); // Debugging statement

setInterval(setTime, 1000);

function setTime() {
  --totalSeconds;
  secondsLabel.innerHTML = pad(totalSeconds % 60);
  minutesLabel.innerHTML = pad(parseInt(totalSeconds / 60));

  if (totalSeconds === 0) {
    document.getElementById("btn").click(); // Trigger the hidden submit button
  }
}

              function pad(val) {
                var valString = val + "";
                if (valString.length < 2) {
                  return "0" + valString;
                } else {
                  return valString;
                }
              }
			  
			  
			  
			  
window.onblur = function() {
  document.getElementById("btn").click();
}

            </script>
          </strong>
        </span>
      </td>
    </tr>
	<?php

	 include("dbconnect.php");

	 $qry=mysqli_query($conn,"select * from question1 where subject='$qname'");
	 $i=1;
	 while($row=mysqli_fetch_array($qry))
	 {
	 if($i==1)
	 {
	 ?>
	  
      <tr>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td height="38">&nbsp;</td>
        <td colspan="6"><strong><?php echo $i;?>.<?php echo $row['question'];?></strong></td>
      </tr>
	 
      <tr>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td height="31">&nbsp;</td>
        <td><input name="q1" type="radio" value="<?php echo $row['ans1'];?>" /><?php echo $row['ans1'];?></td>
        <td><input name="q1" type="radio" value="<?php echo $row['ans2'];?>" /><?php echo $row['ans2'];?></td>
        <td><input name="q1" type="radio" value="<?php echo $row['ans3'];?>" /><?php echo $row['ans3'];?></td>
        <td><input name="q1" type="radio" value="<?php echo $row['ans4'];?>" /><?php echo $row['ans4'];?></td>
        <td colspan="2"><input type="hidden" name="an1" value="<?php echo $row['ans'];?>" /><input type="hidden" name="qs1" value="<?php echo $row['id'];?>" /></td>
      </tr>
	  <?php
	  
	  	  }
	  if($i==2)
	  {
	  ?>
      <tr>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td height="32">&nbsp;</td>
        <td colspan="6"><strong><?php echo $i;?>.<?php echo $row['question'];?></strong></td>
      </tr>
      <tr>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td height="31">&nbsp;</td>
        <td><input name="q2" type="radio" value="<?php echo $row['ans1'];?>" /><?php echo $row['ans1'];?></td>
        <td><input name="q2" type="radio" value="<?php echo $row['ans2'];?>" /><?php echo $row['ans2'];?></td>
        <td><input name="q2" type="radio" value="<?php echo $row['ans3'];?>" /><?php echo $row['ans3'];?></td>
        <td><input name="q2" type="radio" value="<?php echo $row['ans4'];?>" /><?php echo $row['ans4'];?></td>
        <td colspan="2"><input type="hidden" name="an2" value="<?php echo $row['ans'];?>" /><input type="hidden" name="qs2" value="<?php echo $row['id'];?>" /></td>
      </tr>
	  <?php
	  }
	  if($i==3)
	  {
	  ?>
      <tr>
        <td>&nbsp;</td>
       <td>&nbsp;</td>
        <td height="32">&nbsp;</td>
        <td colspan="6"><strong><?php echo $i;?>.<?php echo $row['question'];?></strong></td>
      </tr>
      <tr>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td height="31">&nbsp;</td>
        <td><input name="q3" type="radio" value="<?php echo $row['ans1'];?>" /><?php echo $row['ans1'];?></td>
        <td><input name="q3" type="radio" value="<?php echo $row['ans2'];?>" /><?php echo $row['ans2'];?></td>
        <td><input name="q3" type="radio" value="<?php echo $row['ans3'];?>" /><?php echo $row['ans3'];?></td>
        <td><input name="q3" type="radio" value="<?php echo $row['ans4'];?>" /><?php echo $row['ans4'];?></td>
        <td colspan="2"><input type="hidden" name="an3" value="<?php echo $row['ans'];?>" /><input type="hidden" name="qs3" value="<?php echo $row['id'];?>" /></td>
      </tr>
	  <?php
	  }
	  if($i==4)
	  {
	  ?>
      <tr>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td height="32">&nbsp;</td>
        <td colspan="6"><strong><?php echo $i;?>.<?php echo $row['question'];?></strong></td>
      </tr>
      <tr>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td height="31">&nbsp;</td>
        <td><input name="q4" type="radio" value="<?php echo $row['ans1'];?>" /><?php echo $row['ans1'];?></td>
        <td><input name="q4" type="radio" value="<?php echo $row['ans2'];?>" /><?php echo $row['ans2'];?></td>
        <td><input name="q4" type="radio" value="<?php echo $row['ans3'];?>" /><?php echo $row['ans3'];?></td>
        <td><input name="q4" type="radio" value="<?php echo $row['ans4'];?>" /><?php echo $row['ans4'];?></td>
        <td colspan="2"><input type="hidden" name="an4" value="<?php echo $row['ans'];?>" /><input type="hidden" name="qs4" value="<?php echo $row['id'];?>" /></td>
      </tr>
	   <?php
	  }
	  if($i==5)
	  {
	  ?>
      <tr>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td height="32">&nbsp;</td>
        <td colspan="6"><strong><?php echo $i;?>.<?php echo $row['question'];?></strong></td>
      </tr>
      <tr>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td height="31">&nbsp;</td>
        <td><input name="q5" type="radio" value="<?php echo $row['ans1'];?>" /><?php echo $row['ans1'];?></td>
        <td><input name="q5" type="radio" value="<?php echo $row['ans2'];?>" /><?php echo $row['ans2'];?></td>
        <td><input name="q5" type="radio" value="<?php echo $row['ans3'];?>" /><?php echo $row['ans3'];?></td>
        <td><input name="q5" type="radio" value="<?php echo $row['ans4'];?>" /><?php echo $row['ans4'];?></td>
        <td colspan="2"><input type="hidden" name="an5" value="<?php echo $row['ans'];?>" /><input type="hidden" name="qs5" value="<?php echo $row['id'];?>" /></td>
      </tr>
	   <?php
	  }
	  if($i==6)
	  {
	  ?>
      <tr>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td height="32">&nbsp;</td>
        <td colspan="6"><strong><?php echo $i;?>.<?php echo $row['question'];?></strong></td>
      </tr>
      <tr>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td height="31">&nbsp;</td>
        <td><input name="q6" type="radio" value="<?php echo $row['ans1'];?>" /><?php echo $row['ans1'];?></td>
        <td><input name="q6" type="radio" value="<?php echo $row['ans2'];?>" /><?php echo $row['ans2'];?></td>
        <td><input name="q6" type="radio" value="<?php echo $row['ans3'];?>" /><?php echo $row['ans3'];?></td>
        <td><input name="q6" type="radio" value="<?php echo $row['ans4'];?>" /><?php echo $row['ans4'];?></td>
        <td colspan="2"><input type="hidden" name="an6" value="<?php echo $row['ans'];?>" /><input type="hidden" name="qs6" value="<?php echo $row['id'];?>" /></td>
      </tr>
	   <?php
	  }
	  if($i==7)
	  {
	  ?>
      <tr>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td height="32">&nbsp;</td>
        <td colspan="6"><strong><?php echo $i;?>.<?php echo $row['question'];?></strong></td>
      </tr>
      <tr>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td height="31">&nbsp;</td>
        <td><input name="q7" type="radio" value="<?php echo $row['ans1'];?>" /><?php echo $row['ans1'];?></td>
        <td><input name="q7" type="radio" value="<?php echo $row['ans2'];?>" /><?php echo $row['ans2'];?></td>
        <td><input name="q7" type="radio" value="<?php echo $row['ans3'];?>" /><?php echo $row['ans3'];?></td>
        <td><input name="q7" type="radio" value="<?php echo $row['ans4'];?>" /><?php echo $row['ans4'];?></td>
        <td colspan="2"><input type="hidden" name="an7" value="<?php echo $row['ans'];?>" /><input type="hidden" name="qs7" value="<?php echo $row['id'];?>" /></td>
      </tr>
	    <?php
	  }
	  if($i==8)
	  {
	  ?>
      <tr>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td height="32">&nbsp;</td>
        <td colspan="6"><strong><?php echo $i;?>.<?php echo $row['question'];?></strong></td>
      </tr>
      <tr>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td height="31">&nbsp;</td>
        <td><input name="q8" type="radio" value="<?php echo $row['ans1'];?>" /><?php echo $row['ans1'];?></td>
        <td><input name="q8" type="radio" value="<?php echo $row['ans2'];?>" /><?php echo $row['ans2'];?></td>
        <td><input name="q8" type="radio" value="<?php echo $row['ans3'];?>" /><?php echo $row['ans3'];?></td>
        <td><input name="q8" type="radio" value="<?php echo $row['ans4'];?>" /><?php echo $row['ans4'];?></td>
        <td colspan="2"><input type="hidden" name="an8" value="<?php echo $row['ans'];?>" /> <input type="hidden" name="qs8" value="<?php echo $row['id'];?>" /></td>
      </tr>
	    <?php
	  }
	  if($i==9)
	  {
	  ?>
      <tr>
        <td>&nbsp;</td>
         <td>&nbsp;</td>
        <td height="32">&nbsp;</td>

        <td colspan="6"><strong><?php echo $i;?>.<?php echo $row['question'];?></strong></td>
      </tr>
      <tr>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td height="31">&nbsp;</td>
        <td><input name="q9" type="radio" value="<?php echo $row['ans1'];?>" /><?php echo $row['ans1'];?></td>
        <td><input name="q9" type="radio" value="<?php echo $row['ans2'];?>" /><?php echo $row['ans2'];?></td>
        <td><input name="q9" type="radio" value="<?php echo $row['ans3'];?>" /><?php echo $row['ans3'];?></td>
        <td><input name="q9" type="radio" value="<?php echo $row['ans4'];?>" /><?php echo $row['ans4'];?></td>
        <td colspan="2"><input type="hidden" name="an9" value="<?php echo $row['ans'];?>" /><input type="hidden" name="qs9" value="<?php echo $row['id'];?>" /></td>
      </tr>
	  <?php
	  }
	  if($i==10)
	  {
	  ?> 
      <tr>
        <td>&nbsp;</td>
         <td>&nbsp;</td>
        <td height="32">&nbsp;</td>
        <td colspan="6"><strong><?php echo $i;?>.<?php echo $row['question'];?></strong></td>
      </tr>
      <tr>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td height="31">&nbsp;</td>
        <td><input name="q10" type="radio" value="<?php echo $row['ans1'];?>" /><?php echo $row['ans1'];?></td>
        <td><input name="q10" type="radio" value="<?php echo $row['ans2'];?>" /><?php echo $row['ans2'];?></td>
        <td><input name="q10" type="radio" value="<?php echo $row['ans3'];?>" /><?php echo $row['ans3'];?></td>
        <td><input name="q10" type="radio" value="<?php echo $row['ans4'];?>" /><?php echo $row['ans4'];?></td>
        <td colspan="2"><input type="hidden" name="an10" value="<?php echo $row['ans'];?>" /><input type="hidden" name="qs10" value="<?php echo $row['id'];?>" /></td>
      </tr>
	  <?php
	  }
	    if($i==11)
	  {
	  ?> 
      <tr>
        <td>&nbsp;</td>
         <td>&nbsp;</td>
        <td height="32">&nbsp;</td>
        <td colspan="6"><strong><?php echo $i;?>.<?php echo $row['question'];?></strong></td>
      </tr>
      <tr>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td height="31">&nbsp;</td>
        <td><input name="q11" type="radio" value="<?php echo $row['ans1'];?>" /><?php echo $row['ans1'];?></td>
        <td><input name="q11" type="radio" value="<?php echo $row['ans2'];?>" /><?php echo $row['ans2'];?></td>
        <td><input name="q11" type="radio" value="<?php echo $row['ans3'];?>" /><?php echo $row['ans3'];?></td>
        <td><input name="q11" type="radio" value="<?php echo $row['ans4'];?>" /><?php echo $row['ans4'];?></td>
        <td colspan="2"><input type="hidden" name="an11" value="<?php echo $row['ans'];?>" /><input type="hidden" name="qs11" value="<?php echo $row['id'];?>" /></td>
      </tr>
	  <?php
	  }
	    if($i==12)
	  {
	  ?> 
      <tr>
        <td>&nbsp;</td>
         <td>&nbsp;</td>
        <td height="32">&nbsp;</td>
        <td colspan="6"><strong><?php echo $i;?>.<?php echo $row['question'];?></strong></td>
      </tr>
      <tr>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td height="31">&nbsp;</td>
        <td><input name="q12" type="radio" value="<?php echo $row['ans1'];?>" /><?php echo $row['ans1'];?></td>
        <td><input name="q12" type="radio" value="<?php echo $row['ans2'];?>" /><?php echo $row['ans2'];?></td>
        <td><input name="q12" type="radio" value="<?php echo $row['ans3'];?>" /><?php echo $row['ans3'];?></td>
        <td><input name="q12" type="radio" value="<?php echo $row['ans4'];?>" /><?php echo $row['ans4'];?></td>
        <td colspan="2"><input type="hidden" name="an12" value="<?php echo $row['ans'];?>" /><input type="hidden" name="qs12" value="<?php echo $row['id'];?>" /></td>
      </tr>
	  <?php
	  }
	  
	   if($i==13)
	  {
	  ?> 
      <tr>
        <td>&nbsp;</td>
         <td>&nbsp;</td>
        <td height="32">&nbsp;</td>
        <td colspan="6"><strong><?php echo $i;?>.<?php echo $row['question'];?></strong></td>
      </tr>
      <tr>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td height="31">&nbsp;</td>
        <td><input name="q13" type="radio" value="<?php echo $row['ans1'];?>" /><?php echo $row['ans1'];?></td>
        <td><input name="q13" type="radio" value="<?php echo $row['ans2'];?>" /><?php echo $row['ans2'];?></td>
        <td><input name="q13" type="radio" value="<?php echo $row['ans3'];?>" /><?php echo $row['ans3'];?></td>
        <td><input name="q13" type="radio" value="<?php echo $row['ans4'];?>" /><?php echo $row['ans4'];?></td>
        <td colspan="2"><input type="hidden" name="an13" value="<?php echo $row['ans'];?>" /><input type="hidden" name="qs13" value="<?php echo $row['id'];?>" /></td>
      </tr>
	  <?php
	  }
	  
	  
	   if($i==14)
	  {
	  ?> 
      <tr>
        <td>&nbsp;</td>
         <td>&nbsp;</td>
        <td height="32">&nbsp;</td>
        <td colspan="6"><strong><?php echo $i;?>.<?php echo $row['question'];?></strong></td>
      </tr>
      <tr>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td height="31">&nbsp;</td>
        <td><input name="q14" type="radio" value="<?php echo $row['ans1'];?>" /><?php echo $row['ans1'];?></td>
        <td><input name="q14" type="radio" value="<?php echo $row['ans2'];?>" /><?php echo $row['ans2'];?></td>
        <td><input name="q14" type="radio" value="<?php echo $row['ans3'];?>" /><?php echo $row['ans3'];?></td>
        <td><input name="q14" type="radio" value="<?php echo $row['ans4'];?>" /><?php echo $row['ans4'];?></td>
        <td colspan="2"><input type="hidden" name="an14" value="<?php echo $row['ans'];?>" /><input type="hidden" name="qs14" value="<?php echo $row['id'];?>" /></td>
      </tr>
	  <?php
	  }
	  
	  
	  
	  
	   if($i==15)
	  {
	  ?> 
      <tr>
        <td>&nbsp;</td>
         <td>&nbsp;</td>
        <td height="32">&nbsp;</td>
        <td colspan="6"><strong><?php echo $i;?>.<?php echo $row['question'];?></strong></td>
      </tr>
      <tr>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td height="31">&nbsp;</td>
        <td><input name="q15" type="radio" value="<?php echo $row['ans1'];?>" /><?php echo $row['ans1'];?></td>
        <td><input name="q15" type="radio" value="<?php echo $row['ans2'];?>" /><?php echo $row['ans2'];?></td>
        <td><input name="q15" type="radio" value="<?php echo $row['ans3'];?>" /><?php echo $row['ans3'];?></td>
        <td><input name="q15" type="radio" value="<?php echo $row['ans4'];?>" /><?php echo $row['ans4'];?></td>
        <td colspan="2"><input type="hidden" name="an15" value="<?php echo $row['ans'];?>" /><input type="hidden" name="qs15" value="<?php echo $row['id'];?>" /></td>
      </tr>
	  <?php
	  }
	  
	  
	   if($i==16)
	  {
	  ?> 
      <tr>
        <td>&nbsp;</td>
         <td>&nbsp;</td>
        <td height="32">&nbsp;</td>
        <td colspan="6"><strong><?php echo $i;?>.<?php echo $row['question'];?></strong></td>
      </tr>
      <tr>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td height="31">&nbsp;</td>
        <td><input name="q16" type="radio" value="<?php echo $row['ans1'];?>" /><?php echo $row['ans1'];?></td>
        <td><input name="q16" type="radio" value="<?php echo $row['ans2'];?>" /><?php echo $row['ans2'];?></td>
        <td><input name="q16" type="radio" value="<?php echo $row['ans3'];?>" /><?php echo $row['ans3'];?></td>
        <td><input name="q16" type="radio" value="<?php echo $row['ans4'];?>" /><?php echo $row['ans4'];?></td>
        <td colspan="2"><input type="hidden" name="an16" value="<?php echo $row['ans'];?>" /><input type="hidden" name="qs16" value="<?php echo $row['id'];?>" /></td>
      </tr>
	  <?php
	  }
	  
	  
	  
	   if($i==17)
	  {
	  ?> 
      <tr>
        <td>&nbsp;</td>
         <td>&nbsp;</td>
        <td height="32">&nbsp;</td>
        <td colspan="6"><strong><?php echo $i;?>.<?php echo $row['question'];?></strong></td>
      </tr>
      <tr>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td height="31">&nbsp;</td>
        <td><input name="q17" type="radio" value="<?php echo $row['ans1'];?>" /><?php echo $row['ans1'];?></td>
        <td><input name="q17" type="radio" value="<?php echo $row['ans2'];?>" /><?php echo $row['ans2'];?></td>
        <td><input name="q17" type="radio" value="<?php echo $row['ans3'];?>" /><?php echo $row['ans3'];?></td>
        <td><input name="q17" type="radio" value="<?php echo $row['ans4'];?>" /><?php echo $row['ans4'];?></td>
        <td colspan="2"><input type="hidden" name="an17" value="<?php echo $row['ans'];?>" /><input type="hidden" name="qs17" value="<?php echo $row['id'];?>" /></td>
      </tr>
	  <?php
	  }
	  
	  
	  	   if($i==18)
	  {
	  ?> 
      <tr>
        <td>&nbsp;</td>
         <td>&nbsp;</td>
        <td height="32">&nbsp;</td>
        <td colspan="6"><strong><?php echo $i;?>.<?php echo $row['question'];?></strong></td>
      </tr>
      <tr>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td height="31">&nbsp;</td>
        <td><input name="q18" type="radio" value="<?php echo $row['ans1'];?>" /><?php echo $row['ans1'];?></td>
        <td><input name="q18" type="radio" value="<?php echo $row['ans2'];?>" /><?php echo $row['ans2'];?></td>
        <td><input name="q18" type="radio" value="<?php echo $row['ans3'];?>" /><?php echo $row['ans3'];?></td>
        <td><input name="q18" type="radio" value="<?php echo $row['ans4'];?>" /><?php echo $row['ans4'];?></td>
        <td colspan="2"><input type="hidden" name="an18" value="<?php echo $row['ans'];?>" /><input type="hidden" name="qs18" value="<?php echo $row['id'];?>" /></td>
      </tr>
	  <?php
	  }
	  
	  
	  	   if($i==19)
	  {
	  ?> 
      <tr>
        <td>&nbsp;</td>
         <td>&nbsp;</td>
        <td height="32">&nbsp;</td>
        <td colspan="6"><strong><?php echo $i;?>.<?php echo $row['question'];?></strong></td>
      </tr>
      <tr>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td height="31">&nbsp;</td>
        <td><input name="q19" type="radio" value="<?php echo $row['ans1'];?>" /><?php echo $row['ans1'];?></td>
        <td><input name="q19" type="radio" value="<?php echo $row['ans2'];?>" /><?php echo $row['ans2'];?></td>
        <td><input name="q19" type="radio" value="<?php echo $row['ans3'];?>" /><?php echo $row['ans3'];?></td>
        <td><input name="q19" type="radio" value="<?php echo $row['ans4'];?>" /><?php echo $row['ans4'];?></td>
        <td colspan="2"><input type="hidden" name="an19" value="<?php echo $row['ans'];?>" /><input type="hidden" name="qs19" value="<?php echo $row['id'];?>" /></td>
      </tr>
	  <?php
	  }
	  
	  
	  
	  
	   if($i==20)
	  {
	  ?> 
      <tr>
        <td>&nbsp;</td>
         <td>&nbsp;</td>
        <td height="32">&nbsp;</td>
        <td colspan="6"><strong><?php echo $i;?>.<?php echo $row['question'];?></strong></td>
      </tr>
      <tr>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td height="31">&nbsp;</td>
        <td><input name="q20" type="radio" value="<?php echo $row['ans1'];?>" /><?php echo $row['ans1'];?></td>
        <td><input name="q20" type="radio" value="<?php echo $row['ans2'];?>" /><?php echo $row['ans2'];?></td>
        <td><input name="q20" type="radio" value="<?php echo $row['ans3'];?>" /><?php echo $row['ans3'];?></td>
        <td><input name="q20" type="radio" value="<?php echo $row['ans4'];?>" /><?php echo $row['ans4'];?></td>
        <td colspan="2"><input type="hidden" name="an20" value="<?php echo $row['ans'];?>" /><input type="hidden" name="qs20" value="<?php echo $row['id'];?>" /></td>
      </tr>
	  <?php
	  }
	  
	  
	  
	     if($i==21)
	  {
	  ?> 
      <tr>
        <td>&nbsp;</td>
         <td>&nbsp;</td>
        <td height="32">&nbsp;</td>
        <td colspan="6"><strong><?php echo $i;?>.<?php echo $row['question'];?></strong></td>
      </tr>
      <tr>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td height="31">&nbsp;</td>
        <td><input name="q21" type="radio" value="<?php echo $row['ans1'];?>" /><?php echo $row['ans1'];?></td>
        <td><input name="q21" type="radio" value="<?php echo $row['ans2'];?>" /><?php echo $row['ans2'];?></td>
        <td><input name="q21" type="radio" value="<?php echo $row['ans3'];?>" /><?php echo $row['ans3'];?></td>
        <td><input name="q21" type="radio" value="<?php echo $row['ans4'];?>" /><?php echo $row['ans4'];?></td>
        <td colspan="2"><input type="hidden" name="an21" value="<?php echo $row['ans'];?>" /><input type="hidden" name="qs21" value="<?php echo $row['id'];?>" /></td>
      </tr>
	  <?php
	  }
	  
	  
	  
	  
	       if($i==22)
	  {
	  ?> 
      <tr>
        <td>&nbsp;</td>
         <td>&nbsp;</td>
        <td height="32">&nbsp;</td>
        <td colspan="6"><strong><?php echo $i;?>.<?php echo $row['question'];?></strong></td>
      </tr>
      <tr>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td height="31">&nbsp;</td>
        <td><input name="q22" type="radio" value="<?php echo $row['ans1'];?>" /><?php echo $row['ans1'];?></td>
        <td><input name="q22" type="radio" value="<?php echo $row['ans2'];?>" /><?php echo $row['ans2'];?></td>
        <td><input name="q22" type="radio" value="<?php echo $row['ans3'];?>" /><?php echo $row['ans3'];?></td>
        <td><input name="q22" type="radio" value="<?php echo $row['ans4'];?>" /><?php echo $row['ans4'];?></td>
        <td colspan="2"><input type="hidden" name="an22" value="<?php echo $row['ans'];?>" /><input type="hidden" name="qs22" value="<?php echo $row['id'];?>" /></td>
      </tr>
	  <?php
	  }
	  
	       if($i==23)
	  {
	  ?> 
      <tr>
        <td>&nbsp;</td>
         <td>&nbsp;</td>
        <td height="32">&nbsp;</td>
        <td colspan="6"><strong><?php echo $i;?>.<?php echo $row['question'];?></strong></td>
      </tr>
      <tr>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td height="31">&nbsp;</td>
        <td><input name="q23" type="radio" value="<?php echo $row['ans1'];?>" /><?php echo $row['ans1'];?></td>
        <td><input name="q23" type="radio" value="<?php echo $row['ans2'];?>" /><?php echo $row['ans2'];?></td>
        <td><input name="q23" type="radio" value="<?php echo $row['ans3'];?>" /><?php echo $row['ans3'];?></td>
        <td><input name="q23" type="radio" value="<?php echo $row['ans4'];?>" /><?php echo $row['ans4'];?></td>
        <td colspan="2"><input type="hidden" name="an23" value="<?php echo $row['ans'];?>" /><input type="hidden" name="qs23" value="<?php echo $row['id'];?>" /></td>
      </tr>
	  <?php
	  }
	  
	  
	       if($i==24)
	  {
	  ?> 
      <tr>
        <td>&nbsp;</td>
         <td>&nbsp;</td>
        <td height="32">&nbsp;</td>
        <td colspan="6"><strong><?php echo $i;?>.<?php echo $row['question'];?></strong></td>
      </tr>
      <tr>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td height="31">&nbsp;</td>
        <td><input name="q24" type="radio" value="<?php echo $row['ans1'];?>" /><?php echo $row['ans1'];?></td>
        <td><input name="q24" type="radio" value="<?php echo $row['ans2'];?>" /><?php echo $row['ans2'];?></td>
        <td><input name="q24" type="radio" value="<?php echo $row['ans3'];?>" /><?php echo $row['ans3'];?></td>
        <td><input name="q24" type="radio" value="<?php echo $row['ans4'];?>" /><?php echo $row['ans4'];?></td>
        <td colspan="2"><input type="hidden" name="an24" value="<?php echo $row['ans'];?>" /><input type="hidden" name="qs24" value="<?php echo $row['id'];?>" /></td>
      </tr>
	  <?php
	  }
	  
	       if($i==25)
	  {
	  ?> 
      <tr>
        <td>&nbsp;</td>
         <td>&nbsp;</td>
        <td height="32">&nbsp;</td>
        <td colspan="6"><strong><?php echo $i;?>.<?php echo $row['question'];?></strong></td>
      </tr>
      <tr>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td height="31">&nbsp;</td>
        <td><input name="q25" type="radio" value="<?php echo $row['ans1'];?>" /><?php echo $row['ans1'];?></td>
        <td><input name="q25" type="radio" value="<?php echo $row['ans2'];?>" /><?php echo $row['ans2'];?></td>
        <td><input name="q25" type="radio" value="<?php echo $row['ans3'];?>" /><?php echo $row['ans3'];?></td>
        <td><input name="q25" type="radio" value="<?php echo $row['ans4'];?>" /><?php echo $row['ans4'];?></td>
        <td colspan="2"><input type="hidden" name="an25" value="<?php echo $row['ans'];?>" /><input type="hidden" name="qs25" value="<?php echo $row['id'];?>" /></td>
      </tr>
	  <?php
	  }
	  
	  
	  
	       if($i==26)
	  {
	  ?> 
      <tr>
        <td>&nbsp;</td>
         <td>&nbsp;</td>
        <td height="32">&nbsp;</td>
        <td colspan="6"><strong><?php echo $i;?>.<?php echo $row['question'];?></strong></td>
      </tr>
      <tr>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td height="31">&nbsp;</td>
        <td><input name="q26" type="radio" value="<?php echo $row['ans1'];?>" /><?php echo $row['ans1'];?></td>
        <td><input name="q26" type="radio" value="<?php echo $row['ans2'];?>" /><?php echo $row['ans2'];?></td>
        <td><input name="q26" type="radio" value="<?php echo $row['ans3'];?>" /><?php echo $row['ans3'];?></td>
        <td><input name="q26" type="radio" value="<?php echo $row['ans4'];?>" /><?php echo $row['ans4'];?></td>
        <td colspan="2"><input type="hidden" name="an26" value="<?php echo $row['ans'];?>" /><input type="hidden" name="qs26" value="<?php echo $row['id'];?>" /></td>
      </tr>
	  <?php
	  }
	  
	  
	  
	  
	  
	       if($i==27)
	  {
	  ?> 
      <tr>
        <td>&nbsp;</td>
         <td>&nbsp;</td>
        <td height="32">&nbsp;</td>
        <td colspan="6"><strong><?php echo $i;?>.<?php echo $row['question'];?></strong></td>
      </tr>
      <tr>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td height="31">&nbsp;</td>
        <td><input name="q27" type="radio" value="<?php echo $row['ans1'];?>" /><?php echo $row['ans1'];?></td>
        <td><input name="q27" type="radio" value="<?php echo $row['ans2'];?>" /><?php echo $row['ans2'];?></td>
        <td><input name="q27" type="radio" value="<?php echo $row['ans3'];?>" /><?php echo $row['ans3'];?></td>
        <td><input name="q27" type="radio" value="<?php echo $row['ans4'];?>" /><?php echo $row['ans4'];?></td>
        <td colspan="2"><input type="hidden" name="an27" value="<?php echo $row['ans'];?>" /><input type="hidden" name="qs27" value="<?php echo $row['id'];?>" /></td>
      </tr>
	  <?php
	  }
	       if($i==28)
	  {
	  ?> 
      <tr>
        <td>&nbsp;</td>
         <td>&nbsp;</td>
        <td height="32">&nbsp;</td>
        <td colspan="6"><strong><?php echo $i;?>.<?php echo $row['question'];?></strong></td>
      </tr>
      <tr>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td height="31">&nbsp;</td>
        <td><input name="q28" type="radio" value="<?php echo $row['ans1'];?>" /><?php echo $row['ans1'];?></td>
        <td><input name="q28" type="radio" value="<?php echo $row['ans2'];?>" /><?php echo $row['ans2'];?></td>
        <td><input name="q28" type="radio" value="<?php echo $row['ans3'];?>" /><?php echo $row['ans3'];?></td>
        <td><input name="q28" type="radio" value="<?php echo $row['ans4'];?>" /><?php echo $row['ans4'];?></td>
        <td colspan="2"><input type="hidden" name="an28" value="<?php echo $row['ans'];?>" /><input type="hidden" name="qs28" value="<?php echo $row['id'];?>" /></td>
      </tr>
	  <?php
	  }
	  
	       if($i==29)
	  {
	  ?> 
      <tr>
        <td>&nbsp;</td>
         <td>&nbsp;</td>
        <td height="32">&nbsp;</td>
        <td colspan="6"><strong><?php echo $i;?>.<?php echo $row['question'];?></strong></td>
      </tr>
      <tr>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td height="31">&nbsp;</td>
        <td><input name="q29" type="radio" value="<?php echo $row['ans1'];?>" /><?php echo $row['ans1'];?></td>
        <td><input name="q29" type="radio" value="<?php echo $row['ans2'];?>" /><?php echo $row['ans2'];?></td>
        <td><input name="q29" type="radio" value="<?php echo $row['ans3'];?>" /><?php echo $row['ans3'];?></td>
        <td><input name="q29" type="radio" value="<?php echo $row['ans4'];?>" /><?php echo $row['ans4'];?></td>
        <td colspan="2"><input type="hidden" name="an29" value="<?php echo $row['ans'];?>" /><input type="hidden" name="qs29" value="<?php echo $row['id'];?>" /></td>
      </tr>
	  <?php
	  }
	       if($i==30)
	  {
	  ?> 
      <tr>
        <td>&nbsp;</td>
         <td>&nbsp;</td>
        <td height="32">&nbsp;</td>
        <td colspan="6"><strong><?php echo $i;?>.<?php echo $row['question'];?></strong></td>
      </tr>
      <tr>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td height="31">&nbsp;</td>
        <td><input name="q30" type="radio" value="<?php echo $row['ans1'];?>" /><?php echo $row['ans1'];?></td>
        <td><input name="q30" type="radio" value="<?php echo $row['ans2'];?>" /><?php echo $row['ans2'];?></td>
        <td><input name="q30" type="radio" value="<?php echo $row['ans3'];?>" /><?php echo $row['ans3'];?></td>
        <td><input name="q30" type="radio" value="<?php echo $row['ans4'];?>" /><?php echo $row['ans4'];?></td>
        <td colspan="2"><input type="hidden" name="an30" value="<?php echo $row['ans'];?>" /><input type="hidden" name="qs30" value="<?php echo $row['id'];?>" /></td>
      </tr>
	  <?php
	  }
	  
	  
	  
	   if($i==31)
	  {
	  ?> 
      <tr>
        <td>&nbsp;</td>
         <td>&nbsp;</td>
        <td height="32">&nbsp;</td>
        <td colspan="6"><strong><?php echo $i;?>.<?php echo $row['question'];?></strong></td>
      </tr>
      <tr>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td height="31">&nbsp;</td>
        <td><input name="q31" type="radio" value="<?php echo $row['ans1'];?>" /><?php echo $row['ans1'];?></td>
        <td><input name="q31" type="radio" value="<?php echo $row['ans2'];?>" /><?php echo $row['ans2'];?></td>
        <td><input name="q31" type="radio" value="<?php echo $row['ans3'];?>" /><?php echo $row['ans3'];?></td>
        <td><input name="q31" type="radio" value="<?php echo $row['ans4'];?>" /><?php echo $row['ans4'];?></td>
        <td colspan="2"><input type="hidden" name="an31" value="<?php echo $row['ans'];?>" /><input type="hidden" name="qs31" value="<?php echo $row['id'];?>" /></td>
      </tr>
	  <?php
	  }
	  
	  
	   if($i==32)
	  {
	  ?> 
      <tr>
        <td>&nbsp;</td>
         <td>&nbsp;</td>
        <td height="32">&nbsp;</td>
        <td colspan="6"><strong><?php echo $i;?>.<?php echo $row['question'];?></strong></td>
      </tr>
      <tr>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td height="31">&nbsp;</td>
        <td><input name="q32" type="radio" value="<?php echo $row['ans1'];?>" /><?php echo $row['ans1'];?></td>
        <td><input name="q32" type="radio" value="<?php echo $row['ans2'];?>" /><?php echo $row['ans2'];?></td>
        <td><input name="q32" type="radio" value="<?php echo $row['ans3'];?>" /><?php echo $row['ans3'];?></td>
        <td><input name="q32" type="radio" value="<?php echo $row['ans4'];?>" /><?php echo $row['ans4'];?></td>
        <td colspan="2"><input type="hidden" name="an32" value="<?php echo $row['ans'];?>" /><input type="hidden" name="qs32" value="<?php echo $row['id'];?>" /></td>
      </tr>
	  <?php
	  }
	  
	   if($i==33)
	  {
	  ?> 
      <tr>
        <td>&nbsp;</td>
         <td>&nbsp;</td>
        <td height="32">&nbsp;</td>
        <td colspan="6"><strong><?php echo $i;?>.<?php echo $row['question'];?></strong></td>
      </tr>
      <tr>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td height="31">&nbsp;</td>
        <td><input name="q33" type="radio" value="<?php echo $row['ans1'];?>" /><?php echo $row['ans1'];?></td>
        <td><input name="q33" type="radio" value="<?php echo $row['ans2'];?>" /><?php echo $row['ans2'];?></td>
        <td><input name="q33" type="radio" value="<?php echo $row['ans3'];?>" /><?php echo $row['ans3'];?></td>
        <td><input name="q33" type="radio" value="<?php echo $row['ans4'];?>" /><?php echo $row['ans4'];?></td>
        <td colspan="2"><input type="hidden" name="an33" value="<?php echo $row['ans'];?>" /><input type="hidden" name="qs33" value="<?php echo $row['id'];?>" /></td>
      </tr>
	  <?php
	  }
	  
	    if($i==34)
	  {
	  ?> 
      <tr>
        <td>&nbsp;</td>
         <td>&nbsp;</td>
        <td height="32">&nbsp;</td>
        <td colspan="6"><strong><?php echo $i;?>.<?php echo $row['question'];?></strong></td>
      </tr>
      <tr>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td height="31">&nbsp;</td>
        <td><input name="q34" type="radio" value="<?php echo $row['ans1'];?>" /><?php echo $row['ans1'];?></td>
        <td><input name="q34" type="radio" value="<?php echo $row['ans2'];?>" /><?php echo $row['ans2'];?></td>
        <td><input name="q34" type="radio" value="<?php echo $row['ans3'];?>" /><?php echo $row['ans3'];?></td>
        <td><input name="q34" type="radio" value="<?php echo $row['ans4'];?>" /><?php echo $row['ans4'];?></td>
        <td colspan="2"><input type="hidden" name="an34" value="<?php echo $row['ans'];?>" /><input type="hidden" name="qs34" value="<?php echo $row['id'];?>" /></td>
      </tr>
	  <?php
	  }
	  
	  
	  
	    if($i==35)
	  {
	  ?> 
      <tr>
        <td>&nbsp;</td>
         <td>&nbsp;</td>
        <td height="32">&nbsp;</td>
        <td colspan="6"><strong><?php echo $i;?>.<?php echo $row['question'];?></strong></td>
      </tr>
      <tr>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td height="31">&nbsp;</td>
        <td><input name="q35" type="radio" value="<?php echo $row['ans1'];?>" /><?php echo $row['ans1'];?></td>
        <td><input name="q35" type="radio" value="<?php echo $row['ans2'];?>" /><?php echo $row['ans2'];?></td>
        <td><input name="q35" type="radio" value="<?php echo $row['ans3'];?>" /><?php echo $row['ans3'];?></td>
        <td><input name="q35" type="radio" value="<?php echo $row['ans4'];?>" /><?php echo $row['ans4'];?></td>
        <td colspan="2"><input type="hidden" name="an35" value="<?php echo $row['ans'];?>" /><input type="hidden" name="qs35" value="<?php echo $row['id'];?>" /></td>
      </tr>
	  <?php
	  }
	  
	  
	   if($i==36)
	  {
	  ?> 
      <tr>
        <td>&nbsp;</td>
         <td>&nbsp;</td>
        <td height="32">&nbsp;</td>
        <td colspan="6"><strong><?php echo $i;?>.<?php echo $row['question'];?></strong></td>
      </tr>
      <tr>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td height="31">&nbsp;</td>
        <td><input name="q36" type="radio" value="<?php echo $row['ans1'];?>" /><?php echo $row['ans1'];?></td>
        <td><input name="q36" type="radio" value="<?php echo $row['ans2'];?>" /><?php echo $row['ans2'];?></td>
        <td><input name="q36" type="radio" value="<?php echo $row['ans3'];?>" /><?php echo $row['ans3'];?></td>
        <td><input name="q36" type="radio" value="<?php echo $row['ans4'];?>" /><?php echo $row['ans4'];?></td>
        <td colspan="2"><input type="hidden" name="an36" value="<?php echo $row['ans'];?>" /><input type="hidden" name="qs36" value="<?php echo $row['id'];?>" /></td>
      </tr>
	  <?php
	  }
	  
	   if($i==37)
	  {
	  ?> 
      <tr>
        <td>&nbsp;</td>
         <td>&nbsp;</td>
        <td height="32">&nbsp;</td>
        <td colspan="6"><strong><?php echo $i;?>.<?php echo $row['question'];?></strong></td>
      </tr>
      <tr>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td height="31">&nbsp;</td>
        <td><input name="q37" type="radio" value="<?php echo $row['ans1'];?>" /><?php echo $row['ans1'];?></td>
        <td><input name="q37" type="radio" value="<?php echo $row['ans2'];?>" /><?php echo $row['ans2'];?></td>
        <td><input name="q37" type="radio" value="<?php echo $row['ans3'];?>" /><?php echo $row['ans3'];?></td>
        <td><input name="q37" type="radio" value="<?php echo $row['ans4'];?>" /><?php echo $row['ans4'];?></td>
        <td colspan="2"><input type="hidden" name="an37" value="<?php echo $row['ans'];?>" /><input type="hidden" name="qs35" value="<?php echo $row['id'];?>" /></td>
      </tr>
	  <?php
	  }
	  
	  
	   if($i==38)
	  {
	  ?> 
      <tr>
        <td>&nbsp;</td>
         <td>&nbsp;</td>
        <td height="32">&nbsp;</td>
        <td colspan="6"><strong><?php echo $i;?>.<?php echo $row['question'];?></strong></td>
      </tr>
      <tr>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td height="31">&nbsp;</td>
        <td><input name="q38" type="radio" value="<?php echo $row['ans1'];?>" /><?php echo $row['ans1'];?></td>
        <td><input name="q38" type="radio" value="<?php echo $row['ans2'];?>" /><?php echo $row['ans2'];?></td>
        <td><input name="q38" type="radio" value="<?php echo $row['ans3'];?>" /><?php echo $row['ans3'];?></td>
        <td><input name="q38" type="radio" value="<?php echo $row['ans4'];?>" /><?php echo $row['ans4'];?></td>
        <td colspan="2"><input type="hidden" name="an38" value="<?php echo $row['ans'];?>" /><input type="hidden" name="qs38" value="<?php echo $row['id'];?>" /></td>
      </tr>
	  <?php
	  }
	  
	  
	  if($i==39)
	  {
	  ?> 
      <tr>
        <td>&nbsp;</td>
         <td>&nbsp;</td>
        <td height="32">&nbsp;</td>
        <td colspan="6"><strong><?php echo $i;?>.<?php echo $row['question'];?></strong></td>
      </tr>
      <tr>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td height="31">&nbsp;</td>
        <td><input name="q39" type="radio" value="<?php echo $row['ans1'];?>" /><?php echo $row['ans1'];?></td>
        <td><input name="q39" type="radio" value="<?php echo $row['ans2'];?>" /><?php echo $row['ans2'];?></td>
        <td><input name="q39" type="radio" value="<?php echo $row['ans3'];?>" /><?php echo $row['ans3'];?></td>
        <td><input name="q39" type="radio" value="<?php echo $row['ans4'];?>" /><?php echo $row['ans4'];?></td>
        <td colspan="2"><input type="hidden" name="an39" value="<?php echo $row['ans'];?>" /><input type="hidden" name="qs39" value="<?php echo $row['id'];?>" /></td>
      </tr>
	  <?php
	  }
	  
	  if($i==40)
	  {
	  ?> 
      <tr>
        <td>&nbsp;</td>
         <td>&nbsp;</td>
        <td height="32">&nbsp;</td>
        <td colspan="6"><strong><?php echo $i;?>.<?php echo $row['question'];?></strong></td>
      </tr>
      <tr>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td height="31">&nbsp;</td>
        <td><input name="q40" type="radio" value="<?php echo $row['ans1'];?>" /><?php echo $row['ans1'];?></td>
        <td><input name="q40" type="radio" value="<?php echo $row['ans2'];?>" /><?php echo $row['ans2'];?></td>
        <td><input name="q40" type="radio" value="<?php echo $row['ans3'];?>" /><?php echo $row['ans3'];?></td>
        <td><input name="q40" type="radio" value="<?php echo $row['ans4'];?>" /><?php echo $row['ans4'];?></td>
        <td colspan="2"><input type="hidden" name="an40" value="<?php echo $row['ans'];?>" /><input type="hidden" name="qs40" value="<?php echo $row['id'];?>" /></td>
      </tr>
	  <?php
	  }
	    if($i==41)
	  {
	  ?> 
      <tr>
        <td>&nbsp;</td>
         <td>&nbsp;</td>
        <td height="32">&nbsp;</td>
        <td colspan="6"><strong><?php echo $i;?>.<?php echo $row['question'];?></strong></td>
      </tr>
      <tr>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td height="31">&nbsp;</td>
        <td><input name="q41" type="radio" value="<?php echo $row['ans1'];?>" /><?php echo $row['ans1'];?></td>
        <td><input name="q41" type="radio" value="<?php echo $row['ans2'];?>" /><?php echo $row['ans2'];?></td>
        <td><input name="q41" type="radio" value="<?php echo $row['ans3'];?>" /><?php echo $row['ans3'];?></td>
        <td><input name="q41" type="radio" value="<?php echo $row['ans4'];?>" /><?php echo $row['ans4'];?></td>
        <td colspan="2"><input type="hidden" name="an41" value="<?php echo $row['ans'];?>" /><input type="hidden" name="qs41" value="<?php echo $row['id'];?>" /></td>
      </tr>
	  <?php
	  }
	  
	    if($i==42)
	  {
	  ?> 
      <tr>
        <td>&nbsp;</td>
         <td>&nbsp;</td>
        <td height="32">&nbsp;</td>
        <td colspan="6"><strong><?php echo $i;?>.<?php echo $row['question'];?></strong></td>
      </tr>
      <tr>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td height="31">&nbsp;</td>
        <td><input name="q42" type="radio" value="<?php echo $row['ans1'];?>" /><?php echo $row['ans1'];?></td>
        <td><input name="q42" type="radio" value="<?php echo $row['ans2'];?>" /><?php echo $row['ans2'];?></td>
        <td><input name="q42" type="radio" value="<?php echo $row['ans3'];?>" /><?php echo $row['ans3'];?></td>
        <td><input name="q42" type="radio" value="<?php echo $row['ans4'];?>" /><?php echo $row['ans4'];?></td>
        <td colspan="2"><input type="hidden" name="an42" value="<?php echo $row['ans'];?>" /><input type="hidden" name="qs42" value="<?php echo $row['id'];?>" /></td>
      </tr>
	  <?php
	  }
	  
	  if($i==43)
	  {
	  ?> 
      <tr>
        <td>&nbsp;</td>
         <td>&nbsp;</td>
        <td height="32">&nbsp;</td>
        <td colspan="6"><strong><?php echo $i;?>.<?php echo $row['question'];?></strong></td>
      </tr>
      <tr>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td height="31">&nbsp;</td>
        <td><input name="q43" type="radio" value="<?php echo $row['ans1'];?>" /><?php echo $row['ans1'];?></td>
        <td><input name="q43" type="radio" value="<?php echo $row['ans2'];?>" /><?php echo $row['ans2'];?></td>
        <td><input name="q43" type="radio" value="<?php echo $row['ans3'];?>" /><?php echo $row['ans3'];?></td>
        <td><input name="q43" type="radio" value="<?php echo $row['ans4'];?>" /><?php echo $row['ans4'];?></td>
        <td colspan="2"><input type="hidden" name="an43" value="<?php echo $row['ans'];?>" /><input type="hidden" name="qs43" value="<?php echo $row['id'];?>" /></td>
      </tr>
	  <?php
	  }
	  if($i==44)
	  {
	  ?> 
      <tr>
        <td>&nbsp;</td>
         <td>&nbsp;</td>
        <td height="32">&nbsp;</td>
        <td colspan="6"><strong><?php echo $i;?>.<?php echo $row['question'];?></strong></td>
      </tr>
      <tr>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td height="31">&nbsp;</td>
        <td><input name="q44" type="radio" value="<?php echo $row['ans1'];?>" /><?php echo $row['ans1'];?></td>
        <td><input name="q44" type="radio" value="<?php echo $row['ans2'];?>" /><?php echo $row['ans2'];?></td>
        <td><input name="q44" type="radio" value="<?php echo $row['ans3'];?>" /><?php echo $row['ans3'];?></td>
        <td><input name="q44" type="radio" value="<?php echo $row['ans4'];?>" /><?php echo $row['ans4'];?></td>
        <td colspan="2"><input type="hidden" name="an44" value="<?php echo $row['ans'];?>" /><input type="hidden" name="qs44" value="<?php echo $row['id'];?>" /></td>
      </tr>
	  <?php
	  }
	  
	  if($i==45)
	  {
	  ?> 
      <tr>
        <td>&nbsp;</td>
         <td>&nbsp;</td>
        <td height="32">&nbsp;</td>
        <td colspan="6"><strong><?php echo $i;?>.<?php echo $row['question'];?></strong></td>
      </tr>
      <tr>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td height="31">&nbsp;</td>
        <td><input name="q45" type="radio" value="<?php echo $row['ans1'];?>" /><?php echo $row['ans1'];?></td>
        <td><input name="q45" type="radio" value="<?php echo $row['ans2'];?>" /><?php echo $row['ans2'];?></td>
        <td><input name="q45" type="radio" value="<?php echo $row['ans3'];?>" /><?php echo $row['ans3'];?></td>
        <td><input name="q45" type="radio" value="<?php echo $row['ans4'];?>" /><?php echo $row['ans4'];?></td>
        <td colspan="2"><input type="hidden" name="an45" value="<?php echo $row['ans'];?>" /><input type="hidden" name="qs45" value="<?php echo $row['id'];?>" /></td>
      </tr>
	  <?php
	  }
	  if($i==46)
	  {
	  ?> 
      <tr>
        <td>&nbsp;</td>
         <td>&nbsp;</td>
        <td height="32">&nbsp;</td>
        <td colspan="6"><strong><?php echo $i;?>.<?php echo $row['question'];?></strong></td>
      </tr>
      <tr>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td height="31">&nbsp;</td>
        <td><input name="q46" type="radio" value="<?php echo $row['ans1'];?>" /><?php echo $row['ans1'];?></td>
        <td><input name="q46" type="radio" value="<?php echo $row['ans2'];?>" /><?php echo $row['ans2'];?></td>
        <td><input name="q46" type="radio" value="<?php echo $row['ans3'];?>" /><?php echo $row['ans3'];?></td>
        <td><input name="q46" type="radio" value="<?php echo $row['ans4'];?>" /><?php echo $row['ans4'];?></td>
        <td colspan="2"><input type="hidden" name="an46" value="<?php echo $row['ans'];?>" /><input type="hidden" name="qs46" value="<?php echo $row['id'];?>" /></td>
      </tr>
	  <?php
	  }
	  if($i==47)
	  {
	  ?> 
      <tr>
        <td>&nbsp;</td>
         <td>&nbsp;</td>
        <td height="32">&nbsp;</td>
        <td colspan="6"><strong><?php echo $i;?>.<?php echo $row['question'];?></strong></td>
      </tr>
      <tr>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td height="31">&nbsp;</td>
        <td><input name="q47" type="radio" value="<?php echo $row['ans1'];?>" /><?php echo $row['ans1'];?></td>
        <td><input name="q47" type="radio" value="<?php echo $row['ans2'];?>" /><?php echo $row['ans2'];?></td>
        <td><input name="q47" type="radio" value="<?php echo $row['ans3'];?>" /><?php echo $row['ans3'];?></td>
        <td><input name="q47" type="radio" value="<?php echo $row['ans4'];?>" /><?php echo $row['ans4'];?></td>
        <td colspan="2"><input type="hidden" name="an47" value="<?php echo $row['ans'];?>" /><input type="hidden" name="qs47" value="<?php echo $row['id'];?>" /></td>
      </tr>
	  <?php
	  }
	  if($i==48)
	  {
	  ?> 
      <tr>
        <td>&nbsp;</td>
         <td>&nbsp;</td>
        <td height="32">&nbsp;</td>
        <td colspan="6"><strong><?php echo $i;?>.<?php echo $row['question'];?></strong></td>
      </tr>
      <tr>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td height="31">&nbsp;</td>
        <td><input name="q48" type="radio" value="<?php echo $row['ans1'];?>" /><?php echo $row['ans1'];?></td>
        <td><input name="q48" type="radio" value="<?php echo $row['ans2'];?>" /><?php echo $row['ans2'];?></td>
        <td><input name="q48" type="radio" value="<?php echo $row['ans3'];?>" /><?php echo $row['ans3'];?></td>
        <td><input name="q48" type="radio" value="<?php echo $row['ans4'];?>" /><?php echo $row['ans4'];?></td>
        <td colspan="2"><input type="hidden" name="an48" value="<?php echo $row['ans'];?>" /><input type="hidden" name="qs48" value="<?php echo $row['id'];?>" /></td>
      </tr>
	  <?php
	  }
	  
	  if($i==49)
	  {
	  ?> 
      <tr>
        <td>&nbsp;</td>
         <td>&nbsp;</td>
        <td height="32">&nbsp;</td>
        <td colspan="6"><strong><?php echo $i;?>.<?php echo $row['question'];?></strong></td>
      </tr>
      <tr>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td height="31">&nbsp;</td>
        <td><input name="q49" type="radio" value="<?php echo $row['ans1'];?>" /><?php echo $row['ans1'];?></td>
        <td><input name="q49" type="radio" value="<?php echo $row['ans2'];?>" /><?php echo $row['ans2'];?></td>
        <td><input name="q49" type="radio" value="<?php echo $row['ans3'];?>" /><?php echo $row['ans3'];?></td>
        <td><input name="q49" type="radio" value="<?php echo $row['ans4'];?>" /><?php echo $row['ans4'];?></td>
        <td colspan="2"><input type="hidden" name="an49" value="<?php echo $row['ans'];?>" /><input type="hidden" name="qs49" value="<?php echo $row['id'];?>" /></td>
      </tr>
	  <?php
	  }
	  
	  
	  
	   if($i==50)
	  {
	  ?> 
      <tr>
        <td>&nbsp;</td>
         <td>&nbsp;</td>
        <td height="32">&nbsp;</td>
        <td colspan="6"><strong><?php echo $i;?>.<?php echo $row['question'];?></strong></td>
      </tr>
      <tr>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td height="31">&nbsp;</td>
        <td><input name="q50" type="radio" value="<?php echo $row['ans1'];?>" /><?php echo $row['ans1'];?></td>
        <td><input name="q50" type="radio" value="<?php echo $row['ans2'];?>" /><?php echo $row['ans2'];?></td>
        <td><input name="q50" type="radio" value="<?php echo $row['ans3'];?>" /><?php echo $row['ans3'];?></td>
        <td><input name="q50" type="radio" value="<?php echo $row['ans4'];?>" /><?php echo $row['ans4'];?></td>
        <td colspan="2"><input type="hidden" name="an50" value="<?php echo $row['ans'];?>" /><input type="hidden" name="qs50" value="<?php echo $row['id'];?>" /></td>
      </tr>
	  <?php
	  }
	  
	  $i++;
	  
	  ?>
	  <input type="hidden" name="an" value="<?php echo $i;?>" />
	  
	  <?php
	  }
	  ?>
	  <?php
	  ?>
      <tr>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td height="31">&nbsp;</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td colspan="2">&nbsp;</td>
      </tr>
      <tr>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td height="31">&nbsp;</td>
        <td>&nbsp;</td>
        <td colspan="2"><div align="center">
          <input name="btn" type="submit" id="btn" value="Submit" />
        </div></td>
        <td>&nbsp;</td>
        <td colspan="2">&nbsp;</td>
      </tr>
      <tr>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td colspan="2">&nbsp;</td>
      </tr>
    </table>
  </form>

<br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br />
   
   
    <footer class="footer-wrapper footer-layout1" data-bg-src="assets/img/bg/footer-bg.png">
        <div class="shape-mockup footer-shape1 jump" data-left="60px" data-top="70px"><img src="assets/img/normal/footer-bg-shape1.png" alt="img"></div>
        <div class="shape-mockup footer-shape2 jump-reverse" data-right="80px" data-bottom="120px"><img src="assets/img/normal/footer-bg-shape2.png" alt="img"></div>
        <div class="footer-top">
            <div class="container">
                <div class="footer-contact-wrap">
                    <div class="footer-contact">
                        <div class="footer-contact_icon icon-btn"><i class="fal fa-phone"></i></div>
                        <div class="media-body">
                            <p class="footer-contact_text">Call us any time:</p><a href="tel+11234567890" class="footer-contact_link">+256 214 203 215</a></div>
                    </div>
                    <div class="divider"></div>
                    <div class="footer-contact">
                        <div class="footer-contact_icon icon-btn"><i class="fal fa-envelope"></i></div>
                        <div class="media-body">
                            <p class="footer-contact_text">Email us 24/7 hours:</p><a href="mailto:info@Valluvar College of Science and Management.com" class="footer-contact_link">info@Valluvar College of Science and Management.com</a></div>
                    </div>
                    <div class="divider"></div>
                    <div class="footer-contact">
                        <div class="footer-contact_icon icon-btn"><i class="fal fa-location-dot"></i></div>
                        <div class="media-body">
                            <p class="footer-contact_text">Our university location:</p><a href="https://www.google.com/maps" class="footer-contact_link">New, Madurai Bypass Road, Puthambur, Karur, Tamil Nadu 639003</a></div>
                    </div>
                </div>
            </div>
        </div>
        <div class="footer-wrap" data-bg-src="assets/img/bg/jiji.png">
       
            <div class="container">
                <div class="copyright-wrap">
                    <div class="row justify-content-between align-items-center">
                        <div class="col-md-6">
                            <p class="copyright-text">� Valluvar College of Science and Management , All Rights Reserved. 2024</p>
                        </div>
                        <div class="col-md-6 text-end d-none d-md-block">
                            <div class="footer-links">
                                <ul>
                                    
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </footer>
    <div class="scroll-top"><svg class="progress-circle svg-content" width="100%" height="100%" viewBox="-1 -1 102 102"><path d="M50,1 a49,49 0 0,1 0,98 a49,49 0 0,1 0,-98" style="transition: stroke-dashoffset 10ms linear 0s; stroke-dasharray: 307.919, 307.919; stroke-dashoffset: 307.919;"></path></svg></div>
    <script
        src="assets/js/vendor/jquery-3.6.0.min.js"></script>
        <script src="assets/js/app.min.js"></script>
        <script src="assets/js/main.js"></script>
</body>

</html>