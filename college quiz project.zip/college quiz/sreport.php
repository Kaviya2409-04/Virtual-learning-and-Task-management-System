<?php 

include("dbconnect.php");
	  session_start();
	  extract($_POST);
?>
<!doctype html>
<html class="no-js" lang="zxx">

<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>Virtual learning and task management system</title>
    <meta name="author" content="themeholy">
    <meta name="description" content="Edura -  Courses & Education HTML Template">
    <meta name="keywords" content="Edura -  Courses & Education HTML Template">
    <meta name="robots" content="INDEX,FOLLOW">
    <meta name="viewport" content="width=device-width,initial-scale=1,shrink-to-fit=no">
    <link rel="apple-touch-icon" sizes="57x57" href="assets/img/favicons/apple-icon-57x57.png">
    <link rel="apple-touch-icon" sizes="60x60" href="assets/img/favicons/apple-icon-60x60.png">
    <link rel="apple-touch-icon" sizes="72x72" href="assets/img/favicons/apple-icon-72x72.png">
    <link rel="apple-touch-icon" sizes="76x76" href="assets/img/favicons/apple-icon-76x76.png">
    <link rel="apple-touch-icon" sizes="114x114" href="assets/img/favicons/apple-icon-114x114.png">
    <link rel="apple-touch-icon" sizes="120x120" href="assets/img/favicons/apple-icon-120x120.png">
    <link rel="apple-touch-icon" sizes="144x144" href="assets/img/favicons/apple-icon-144x144.png">
    <link rel="apple-touch-icon" sizes="152x152" href="assets/img/favicons/apple-icon-152x152.png">
    <link rel="apple-touch-icon" sizes="180x180" href="assets/img/favicons/apple-icon-180x180.png">
    <link rel="icon" type="image/png" sizes="192x192" href="assets/img/favicons/android-icon-192x192.png">
    <link rel="icon" type="image/png" sizes="32x32" href="assets/img/favicons/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="96x96" href="assets/img/favicons/favicon-96x96.png">
    <link rel="icon" type="image/png" sizes="16x16" href="assets/img/favicons/favicon-16x16.png">
    <link rel="manifest" href="assets/img/favicons/manifest.json">
    <meta name="msapplication-TileColor" content="#ffffff">
    <meta name="msapplication-TileImage" content="assets/img/favicons/ms-icon-144x144.png">
    <meta name="theme-color" content="#ffffff">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Baloo+2:wght@400;500;600;700;800&family=Jost:wght@300;400;500;600;700;800;900&family=Roboto:wght@100;300;400;500;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/app.min.css">
    <link rel="stylesheet" href="assets/css/fontawesome.min.css">
    <link rel="stylesheet" href="assets/css/style.css">
		<script src="https://kit.fontawesome.com/1fb451dce7.js" crossorigin="anonymous"></script>
</head>

<body>
    <div class="preloader"><button class="th-btn style3 preloaderCls">Cancel Preloader</button>
        <div class="preloader-inner"><span class="loader"></span></div>
    </div>
		<img src="download.png" style="width:100px;height:100px;border-radius:50%;position:absolute;z-index:100;top:20px;left:50px;border:5px solid white;">
    <div class="sidemenu-wrapper d-none d-lg-block">
        <div class="sidemenu-content"><button class="closeButton sideMenuCls"><i class="far fa-times"></i></button>
            <div class="widget woocommerce widget_shopping_cart">
                <h3 class="widget_title">Shopping cart</h3>
                <div class="widget_shopping_cart_content">
                    <ul class="woocommerce-mini-cart cart_list product_list_widget">
                        <li class="woocommerce-mini-cart-item mini_cart_item"><a href="#" class="remove remove_from_cart_button"><i class="far fa-times"></i></a> <a href="#"><img src="assets/img/product/product_thumb_1_1.jpg" alt="Cart Image">Plastic Book Bags</a> <span class="quantity">1 ? <span class="woocommerce-Price-amount amount"><span class="woocommerce-Price-currencySymbol">$</span>940.00</span>
                            </span>
                        </li>
                        <li class="woocommerce-mini-cart-item mini_cart_item"><a href="#" class="remove remove_from_cart_button"><i class="far fa-times"></i></a> <a href="#"><img src="assets/img/product/product_thumb_1_2.jpg" alt="Cart Image">The Genie Mind</a> <span class="quantity">1 ? <span class="woocommerce-Price-amount amount"><span class="woocommerce-Price-currencySymbol">$</span>899.00</span>
                            </span>
                        </li>
                        <li class="woocommerce-mini-cart-item mini_cart_item"><a href="#" class="remove remove_from_cart_button"><i class="far fa-times"></i></a> <a href="#"><img src="assets/img/product/product_thumb_1_3.jpg" alt="Cart Image">The Energy Book</a> <span class="quantity">1 ? <span class="woocommerce-Price-amount amount"><span class="woocommerce-Price-currencySymbol">$</span>756.00</span>
                            </span>
                        </li>
                        <li class="woocommerce-mini-cart-item mini_cart_item"><a href="#" class="remove remove_from_cart_button"><i class="far fa-times"></i></a> <a href="#"><img src="assets/img/product/product_thumb_1_4.jpg" alt="Cart Image">Pencil Bag</a> <span class="quantity">1 ? <span class="woocommerce-Price-amount amount"><span class="woocommerce-Price-currencySymbol">$</span>723.00</span>
                            </span>
                        </li>
                        <li class="woocommerce-mini-cart-item mini_cart_item"><a href="#" class="remove remove_from_cart_button"><i class="far fa-times"></i></a> <a href="#"><img src="assets/img/product/product_thumb_1_5.jpg" alt="Cart Image">Sharpner</a> <span class="quantity">1 ? <span class="woocommerce-Price-amount amount"><span class="woocommerce-Price-currencySymbol">$</span>1080.00</span>
                            </span>
                        </li>
                    </ul>
                    <p class="woocommerce-mini-cart__total total"><strong>Subtotal:</strong> <span class="woocommerce-Price-amount amount"><span class="woocommerce-Price-currencySymbol">$</span>4398.00</span>
                    </p>
                    <p class="woocommerce-mini-cart__buttons buttons"><a href="cart.html" class="th-btn wc-forward">View cart</a> <a href="checkout.html" class="th-btn checkout wc-forward">Checkout</a></p>
                </div>
            </div>
        </div>
    </div>
    <div class="popup-search-box d-none d-lg-block"><button class="searchClose"><i class="fal fa-times"></i></button>
        <form action="#"><input type="text" placeholder="What are you looking for?"> <button type="submit"><i class="fal fa-search"></i></button></form>
    </div>
    <div class="th-menu-wrapper">
        <div class="th-menu-area text-center"><button class="th-menu-toggle"><i class="fal fa-times"></i></button>
            <div class="mobile-logo"><a href="index.html"><img src="assets/img/logo.svg" alt="Edura"></a></div>
            <div class="th-mobile-menu">
                <ul>
                    <li class="menu-item-has-children"><a href="index.html">Home</a>
                     
                    <li class="menu-item-has-children"><a href="#">Blog</a>
                        <ul class="sub-menu">
                            <li><a href="blog.html">Blog</a></li>
                            <li><a href="blog-details.html">Blog Details</a></li>
                        </ul>
                    </li>
                    <li><a href="contact.html">Contact</a></li>
                </ul>
            </div>
        </div>
    </div>
    <header class="th-header header-layout1 onepage-nav">
        <div class="header-top">
            <div class="container">
                <div class="row justify-content-center justify-content-lg-between align-items-center gy-2">
                    <div class="col-auto d-none d-lg-block">
                        <div class="header-links">
                            <ul>
                                <li><i class="far fa-phone"></i><a href="tel:+11156456825">+91 9788349333</a></li>
                                <li class="d-none d-xl-inline-block"><i class="far fa-envelope"></i><a href="mailto:info@valluvar.com">info@valluvar.com</a></li>
                                <li><i class="far fa-clock"></i>Mon - Sat: 8:00 - 15:00</li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-auto">
                        <div class="header-links header-right">
                            <ul>
                                <li>
                                    <div class="header-social"><span class="social-title">Follow Us:</span> <a href="https://www.facebook.com/"><i class="fab fa-facebook-f"></i></a> <a href="https://www.twitter.com/"><i class="fab fa-twitter"></i></a> <a href="https://www.linkedin.com/"><i class="fab fa-linkedin-in"></i></a>                                        <a href="https://www.youtube.com/"><i class="fab fa-youtube"></i></a> <a href="https://www.instagram.com/"><i class="fab fa-skype"></i></a></div>
                                </li>
                              
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="sticky-wrapper">
            <div class="menu-area">
                <div class="container">
                    <div class="row align-items-center justify-content-between">
                        <div class="col-auto">
                            <div class="header-logo"><h3 style="color:#0d5ef4">Virtual learning and task management system</h3></div>
                        </div>
                        <div class="col-auto">
                            <div class="row">
                                <div class="col-auto">
                                    <nav class="main-menu d-none d-lg-inline-block">
                                        <ul>
                                            <li ><a href="stuhome.php">Home</a>
											 <li ><a href="sclass.php">View Class</a>
											   <li ><a href="dmaterial.php"> Material</a>
														       <li ><a href="dassign.php">View Assignment</a>
															   <li ><a href="uploadassign.php">Upload Assignment</a>
															    <li ><a href="sreport.php">Report</a>
																  <li ><a href="index.php">Logout</a> </li>
											   </ul>
                                    </nav><button type="button" class="th-menu-toggle d-block d-lg-none"><i class="far fa-bars"></i></button></div>
                          
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </header>
    <div class="th-hero-wrapper hero-1" id="hero">
        <div class="hero-slider-1 th-carousel" data-fade="true" data-slide-show="1" data-md-slide-show="1" data-dots="true">
            <div class="th-hero-slide">
                <div class="th-hero-bg" data-overlay="title" data-opacity="8" data-bg-src="assets/img/hero/hero_bg_1_1.jpg"></div>
                <div class="container">
                    <div class="row align-items-center justify-content-center">
                        <div class="col-md-6">
                            <div class="hero-style1"><span class="hero-subtitle" data-ani="slideinleft" data-ani-delay="0.1s"><span></span> LEARN FROM TODAY</span>
                                <h1 class="hero-title text-white" data-ani="slideinleft" data-ani-delay="0.4s">Education Is Create Better <span class="text-theme">Future.</span></h1>
                                <p class="hero-text" data-ani="slideinleft" data-ani-delay="0.6s">Education can be thought of as the transmission of the values and accumulated knowledge of a society. In this sense, it is equivalent.</p>
                            </div>
                        </div>
                        <div class="col-md-6 text-lg-end text-center">
                            <div class="hero-img1"><img src="assets/img/hero/hero_thumb_1_1.jpg" alt="hero"></div>
                        </div>
                    </div>
                </div>
                <div class="hero-shape shape1"><img src="assets/img/hero/shape_1_1.png" alt="shape"></div>
                <div class="hero-shape shape2"><img src="assets/img/hero/shape_1_2.png" alt="shape"></div>
                <div class="hero-shape shape3"></div>
                <div class="hero-shape shape4 shape-mockup jump-reverse" data-right="3%" data-bottom="7%"><img src="assets/img/hero/shape_1_3.png" alt="shape"></div>
                <div class="hero-shape shape5 shape-mockup jump-reverse" data-left="0" data-bottom="0"><img src="assets/img/hero/shape_1_4.png" alt="shape"></div>
            </div>
            <div class="th-hero-slide">
                <div class="th-hero-bg" data-overlay="title" data-opacity="8" data-bg-src="assets/img/hero/hero_bg_1_2.jpg"></div>
                <div class="container">
                    <div class="row align-items-center justify-content-center">
                        <div class="col-md-6">
                            <div class="hero-style1"><span class="hero-subtitle" data-ani="slideinleft" data-ani-delay="0.1s"><span></span> LEARN FROM TODAY</span>
                                <h1 class="hero-title text-white" data-ani="slideinleft" data-ani-delay="0.4s">Edura Leads To A Brighter <span class="text-theme">Future.</span></h1>
                                <p class="hero-text" data-ani="slideinleft" data-ani-delay="0.6s">Education can be thought of as the transmission of a societys values and accumulated knowledge. In this sense, it is equivalent.</p>
                            </div>
                        </div>
                        <div class="col-md-6 text-lg-end text-center">
                            <div class="hero-img1"><img src="assets/img/hero/hero_thumb_1_2.jpg" alt="hero"></div>
                        </div>
                    </div>
                </div>
                <div class="hero-shape shape1"><img src="assets/img/hero/shape_1_1.png" alt="shape"></div>
                <div class="hero-shape shape2"><img src="assets/img/hero/shape_1_2.png" alt="shape"></div>
                <div class="hero-shape shape3"></div>
                <div class="hero-shape shape4 shape-mockup jump-reverse" data-right="3%" data-bottom="7%"><img src="assets/img/hero/shape_1_3.png" alt="shape"></div>
                <div class="hero-shape shape5 shape-mockup jump-reverse" data-left="0" data-bottom="0"><img src="assets/img/hero/shape_1_4.png" alt="shape"></div>
            </div>
            <div class="th-hero-slide">
                <div class="th-hero-bg" data-overlay="title" data-opacity="8" data-bg-src="assets/img/hero/hero_bg_1_3.jpg"></div>
                <div class="container">
                    <div class="row align-items-center justify-content-center">
                        <div class="col-md-6">
                            <div class="hero-style1"><span class="hero-subtitle" data-ani="slideinleft" data-ani-delay="0.1s"><span></span> LEARN FROM TODAY</span>
                                <h1 class="hero-title text-white" data-ani="slideinleft" data-ani-delay="0.4s">The Worlds Best  Education <span class="text-theme">Institute.</span></h1>
                                <p class="hero-text" data-ani="slideinleft" data-ani-delay="0.6s">Education can be thought of as the transmission of the values and accumulated knowledge of a society. In this sense, it is equivalent.</p>
                            </div>
                        </div>
                        <div class="col-md-6 text-lg-end text-center">
                            <div class="hero-img1"><img src="assets/img/hero/hero_thumb_1_3.jpg" alt="hero"></div>
                        </div>
                    </div>
                </div>
                <div class="hero-shape shape1"><img src="assets/img/hero/shape_1_1.png" alt="shape"></div>





                <div class="hero-shape shape2"><img src="assets/img/hero/shape_1_2.png" alt="shape"></div>
                <div class="hero-shape shape3"></div>
                <div class="hero-shape shape4 shape-mockup jump-reverse" data-right="3%" data-bottom="7%"><img src="assets/img/hero/shape_1_3.png" alt="shape"></div>
                <div class="hero-shape shape5 shape-mockup jump-reverse" data-left="0" data-bottom="0"><img src="assets/img/hero/shape_1_4.png" alt="shape"></div>
            </div>
        </div>
    </div>
   
   
   
    <br />
<br /><br /><br /><br /><br />

<h2 style="width:300px;margin:0 auto;">Report</h2>




<h2>Quizz Result:</h2>
<table border="2">



 <tr>
        <td height="38"><div align="center"></div></td>
        <td><div align="center">SNO</div></td>
        <td><div align="center">Subject</div></td>
		<td><div align="center">Total Questions</div></td>
		<td><div align="center">Marks</div></td>
     
	
      <tr>


 <?php
	  
	  $uid=$_SESSION['un'];
	  $qr=mysqli_query($conn,"select * from student where id='$uid'");
	  $r=mysqli_fetch_array($qr);
  $year=$r['year'];
	   $depart=$r['dept'];
	 $desti=$r['desti'];
	 $sec=$r['class'];
	  
	  $qry=mysqli_query($conn,"select * from result where nid='$uid' ");
	  $i=1;
	  while($row=mysqli_fetch_array($qry))
	  {
	  ?>
      <tr>
        <td height="38"><div align="center"></div></td>
        <td><div align="center"><?php echo $i;?></div></td>
        <td><div align="center"><?php echo $row['test'];?></div></td>
		 <td><div align="center"><?php echo $row['tqus'];?></div></td>
		  <td><div align="center"><?php echo $row['result'];?></div></td>

     
	  <?php
	  $i++;
	  }
	  ?>
      <tr>
        <td height="31">&nbsp;</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
      </tr>
     
    </table>
  </form>



<br /><br />

<h2>Uploaded Assignment:</h2>
<table border="2">



 <tr>
        <td height="38"><div align="center"></div></td>
        <td><div align="center">SNO</div></td>
        <td><div align="center">Subject</div></td>
		<td><div align="center">Download</div></td>
     
	
      <tr>


 <?php
	  
	  
	  
	  $qry=mysqli_query($conn,"select * from assi1 where regno='$uid' ");
	  $i=1;
	  while($row=mysqli_fetch_array($qry))
	  {
	  ?>
      <tr>
        <td height="38"><div align="center"></div></td>
        <td><div align="center"><?php echo $i;?></div></td>
        <td><div align="center"><?php echo $row['subject'];?></div></td>
		<td><div align="center"><a href="upload/<?php echo $row['img'];?>" download>Download Now</a></div></td>
     
	  <?php
	  $i++;
	  }
	  ?>
      <tr>
        <td height="31">&nbsp;</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
      </tr>
     
    </table>
  </form>






<br /><br />
   
   
    <footer class="footer-wrapper footer-layout1" data-bg-src="assets/img/bg/footer-bg.png">
        <div class="shape-mockup footer-shape1 jump" data-left="60px" data-top="70px"><img src="assets/img/normal/footer-bg-shape1.png" alt="img"></div>
        <div class="shape-mockup footer-shape2 jump-reverse" data-right="80px" data-bottom="120px"><img src="assets/img/normal/footer-bg-shape2.png" alt="img"></div>
        <div class="footer-top">
            <div class="container">
                <div class="footer-contact-wrap">
                    <div class="footer-contact">
                        <div class="footer-contact_icon icon-btn"><i class="fal fa-phone"></i></div>
                        <div class="media-body">
                            <p class="footer-contact_text">Call us any time:</p><a href="tel+11234567890" class="footer-contact_link">+256 214 203 215</a></div>
                    </div>
                    <div class="divider"></div>
                    <div class="footer-contact">
                        <div class="footer-contact_icon icon-btn"><i class="fal fa-envelope"></i></div>
                        <div class="media-body">
                            <p class="footer-contact_text">Email us 24/7 hours:</p><a href="mailto:info@valluvar.com" class="footer-contact_link">info@valluvar.com</a></div>
                    </div>
                    <div class="divider"></div>
                    <div class="footer-contact">
                        <div class="footer-contact_icon icon-btn"><i class="fal fa-location-dot"></i></div>
                        <div class="media-body">
                            <p class="footer-contact_text">Our university location:</p><a href="https://www.google.com/maps" class="footer-contact_link">New, Madurai Bypass Road, Puthambur, Karur, Tamil Nadu 639003</a></div>
                    </div>
                </div>
            </div>
        </div>
        <div class="footer-wrap" data-bg-src="assets/img/bg/jiji.png">
       
            <div class="container">
                <div class="copyright-wrap">
                    <div class="row justify-content-between align-items-center">
                        <div class="col-md-6">
                            <p class="copyright-text">? Valluvar College of Science and Management, All Rights Reserved. 2024</p>
                        </div>
                        <div class="col-md-6 text-end d-none d-md-block">
                            <div class="footer-links">
                                <ul>
                                    
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </footer>
    <div class="scroll-top"><svg class="progress-circle svg-content" width="100%" height="100%" viewBox="-1 -1 102 102"><path d="M50,1 a49,49 0 0,1 0,98 a49,49 0 0,1 0,-98" style="transition: stroke-dashoffset 10ms linear 0s; stroke-dasharray: 307.919, 307.919; stroke-dashoffset: 307.919;"></path></svg></div>
    <script
        src="assets/js/vendor/jquery-3.6.0.min.js"></script>
        <script src="assets/js/app.min.js"></script>
        <script src="assets/js/main.js"></script>
</body>

</html>