-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 23, 2024 at 01:34 PM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 8.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `onlineexam1`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `uname` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`uname`, `password`) VALUES
('admin', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `assi`
--

CREATE TABLE `assi` (
  `id` int(50) NOT NULL,
  `year` varchar(50) NOT NULL,
  `depart` varchar(50) NOT NULL,
  `exam` varchar(50) NOT NULL,
  `subject` varchar(50) NOT NULL,
  `img` varchar(255) NOT NULL,
  `desti` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `assi`
--

INSERT INTO `assi` (`id`, `year`, `depart`, `exam`, `subject`, `img`, `desti`) VALUES
(2, '3 Year', 'b.com', 'ANDROID', 'ANDROID', 'cert.pdf', 'UG');

-- --------------------------------------------------------

--
-- Table structure for table `assi1`
--

CREATE TABLE `assi1` (
  `id` int(50) NOT NULL,
  `year` varchar(50) NOT NULL,
  `depart` varchar(50) NOT NULL,
  `exam` varchar(50) NOT NULL,
  `subject` varchar(50) NOT NULL,
  `img` varchar(255) NOT NULL,
  `desti` varchar(100) NOT NULL,
  `regno` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `assi1`
--

INSERT INTO `assi1` (`id`, `year`, `depart`, `exam`, `subject`, `img`, `desti`, `regno`) VALUES
(2, '3 Year', 'b.com', 'ANDROID', 'ANDROID', 'certificate2.docx', 'UG', '1');

-- --------------------------------------------------------

--
-- Table structure for table `cls`
--

CREATE TABLE `cls` (
  `id` int(50) NOT NULL,
  `year` varchar(50) NOT NULL,
  `depart` varchar(50) NOT NULL,
  `exam` varchar(50) NOT NULL,
  `subject` varchar(50) NOT NULL,
  `sect` varchar(255) NOT NULL,
  `desti` varchar(100) NOT NULL,
  `link` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `cls`
--

INSERT INTO `cls` (`id`, `year`, `depart`, `exam`, `subject`, `sect`, `desti`, `link`) VALUES
(1, '3 Year', 'b.com', 'ANDROID', 'ANDROID', 'A', 'UG', 'https://www.youtube.com/results?search_query=ANDROID');

-- --------------------------------------------------------

--
-- Table structure for table `exam`
--

CREATE TABLE `exam` (
  `id` int(10) NOT NULL,
  `etype` varchar(30) NOT NULL,
  `depart` varchar(20) NOT NULL,
  `year` varchar(20) NOT NULL,
  `subject` varchar(60) NOT NULL,
  `date` varchar(20) NOT NULL,
  `session` varchar(20) NOT NULL,
  `desti` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `exam`
--

INSERT INTO `exam` (`id`, `etype`, `depart`, `year`, `subject`, `date`, `session`, `desti`) VALUES
(1, 'ANDROID', 'b.com', '3 Year', 'ANDROID', '2024-01-23', 'AN', 'UG');

-- --------------------------------------------------------

--
-- Table structure for table `material`
--

CREATE TABLE `material` (
  `id` int(50) NOT NULL,
  `year` varchar(50) NOT NULL,
  `depart` varchar(50) NOT NULL,
  `exam` varchar(50) NOT NULL,
  `subject` varchar(50) NOT NULL,
  `img` varchar(255) NOT NULL,
  `desti` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `material`
--

INSERT INTO `material` (`id`, `year`, `depart`, `exam`, `subject`, `img`, `desti`) VALUES
(2, '3 Year', 'b.com', 'ANDROID', 'ANDROID', 'Course Register.pdf', 'UG');

-- --------------------------------------------------------

--
-- Table structure for table `question1`
--

CREATE TABLE `question1` (
  `id` int(50) NOT NULL,
  `year` varchar(50) NOT NULL,
  `depart` varchar(50) NOT NULL,
  `exam` varchar(50) NOT NULL,
  `subject` varchar(50) NOT NULL,
  `question` varchar(50) NOT NULL,
  `ans1` varchar(50) NOT NULL,
  `ans2` varchar(50) NOT NULL,
  `ans3` varchar(50) NOT NULL,
  `ans4` varchar(50) NOT NULL,
  `ans` varchar(50) NOT NULL,
  `desti` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `question1`
--

INSERT INTO `question1` (`id`, `year`, `depart`, `exam`, `subject`, `question`, `ans1`, `ans2`, `ans3`, `ans4`, `ans`, `desti`) VALUES
(1, '3 Year', 'b.com', 'ANDROID', 'ANDROID', 'WHAT IS?', 'J', 'JO', 'JOY', 'JOYA', 'JO', 'UG');

-- --------------------------------------------------------

--
-- Table structure for table `result`
--

CREATE TABLE `result` (
  `id` int(50) NOT NULL,
  `nid` varchar(50) NOT NULL,
  `name` varchar(50) NOT NULL,
  `test` varchar(50) NOT NULL,
  `tqus` varchar(50) NOT NULL,
  `result` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `result`
--

INSERT INTO `result` (`id`, `nid`, `name`, `test`, `tqus`, `result`) VALUES
(1, '1', '1', 'ANDROID', '1', '1');

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE `student` (
  `id` int(10) NOT NULL,
  `regno` varchar(20) NOT NULL,
  `name` varchar(40) NOT NULL,
  `gender` varchar(40) NOT NULL,
  `dob` varchar(40) NOT NULL,
  `dept` varchar(40) NOT NULL,
  `year` varchar(40) NOT NULL,
  `sem` varchar(20) NOT NULL,
  `class` varchar(40) NOT NULL,
  `address` varchar(40) NOT NULL,
  `pnumber` varchar(10) NOT NULL,
  `email` varchar(40) NOT NULL,
  `desti` varchar(100) NOT NULL,
  `password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`id`, `regno`, `name`, `gender`, `dob`, `dept`, `year`, `sem`, `class`, `address`, `pnumber`, `email`, `desti`, `password`) VALUES
(1, 'JO', 'JOYAL', 'male', '2001-10-25', 'b.com', '3 Year', '3', 'A', 'TRICHTY', '6789678866', 'fantasyphpproject@gmail.com', 'UG', '123');

-- --------------------------------------------------------

--
-- Table structure for table `uques`
--

CREATE TABLE `uques` (
  `id` int(10) NOT NULL,
  `uid` int(10) NOT NULL,
  `q1` text NOT NULL,
  `q2` text NOT NULL,
  `q3` text NOT NULL,
  `q4` text NOT NULL,
  `q5` text NOT NULL,
  `q6` text NOT NULL,
  `q7` text NOT NULL,
  `q8` text NOT NULL,
  `q9` text NOT NULL,
  `q10` text NOT NULL,
  `q11` text NOT NULL,
  `q12` text NOT NULL,
  `q13` text NOT NULL,
  `q14` text NOT NULL,
  `q15` text NOT NULL,
  `q16` text NOT NULL,
  `q17` text NOT NULL,
  `q18` text NOT NULL,
  `q19` text NOT NULL,
  `q20` text NOT NULL,
  `q21` text NOT NULL,
  `q22` text NOT NULL,
  `q23` text NOT NULL,
  `q24` text NOT NULL,
  `q25` text NOT NULL,
  `q26` text NOT NULL,
  `q27` text NOT NULL,
  `q28` text NOT NULL,
  `q29` text NOT NULL,
  `q30` text NOT NULL,
  `q31` text NOT NULL,
  `q32` text NOT NULL,
  `q33` text NOT NULL,
  `q34` text NOT NULL,
  `q35` text NOT NULL,
  `q36` text NOT NULL,
  `q37` text NOT NULL,
  `q38` text NOT NULL,
  `q39` text NOT NULL,
  `q40` text NOT NULL,
  `q41` text NOT NULL,
  `q42` text NOT NULL,
  `q43` text NOT NULL,
  `q44` text NOT NULL,
  `q45` text NOT NULL,
  `q46` text NOT NULL,
  `q47` text NOT NULL,
  `q48` text NOT NULL,
  `q49` text NOT NULL,
  `q50` text NOT NULL,
  `a1` text NOT NULL,
  `a2` text NOT NULL,
  `a3` text NOT NULL,
  `a4` text NOT NULL,
  `a5` text NOT NULL,
  `a6` text NOT NULL,
  `a7` text NOT NULL,
  `a8` text NOT NULL,
  `a9` text NOT NULL,
  `a10` text NOT NULL,
  `a11` text NOT NULL,
  `a12` text NOT NULL,
  `a13` text NOT NULL,
  `a14` text NOT NULL,
  `a15` text NOT NULL,
  `a16` text NOT NULL,
  `a17` text NOT NULL,
  `a18` text NOT NULL,
  `a19` text NOT NULL,
  `a20` text NOT NULL,
  `a21` text NOT NULL,
  `a22` text NOT NULL,
  `a23` text NOT NULL,
  `a24` text NOT NULL,
  `a25` text NOT NULL,
  `a26` text NOT NULL,
  `a27` text NOT NULL,
  `a28` text NOT NULL,
  `a29` text NOT NULL,
  `a30` text NOT NULL,
  `a31` text NOT NULL,
  `a32` text NOT NULL,
  `a33` text NOT NULL,
  `a34` text NOT NULL,
  `a35` text NOT NULL,
  `a36` text NOT NULL,
  `a37` text NOT NULL,
  `a38` text NOT NULL,
  `a39` text NOT NULL,
  `a40` text NOT NULL,
  `a41` text NOT NULL,
  `a42` text NOT NULL,
  `a43` text NOT NULL,
  `a44` text NOT NULL,
  `a45` text NOT NULL,
  `a46` text NOT NULL,
  `a47` text NOT NULL,
  `a48` text NOT NULL,
  `a49` text NOT NULL,
  `a50` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `uques`
--

INSERT INTO `uques` (`id`, `uid`, `q1`, `q2`, `q3`, `q4`, `q5`, `q6`, `q7`, `q8`, `q9`, `q10`, `q11`, `q12`, `q13`, `q14`, `q15`, `q16`, `q17`, `q18`, `q19`, `q20`, `q21`, `q22`, `q23`, `q24`, `q25`, `q26`, `q27`, `q28`, `q29`, `q30`, `q31`, `q32`, `q33`, `q34`, `q35`, `q36`, `q37`, `q38`, `q39`, `q40`, `q41`, `q42`, `q43`, `q44`, `q45`, `q46`, `q47`, `q48`, `q49`, `q50`, `a1`, `a2`, `a3`, `a4`, `a5`, `a6`, `a7`, `a8`, `a9`, `a10`, `a11`, `a12`, `a13`, `a14`, `a15`, `a16`, `a17`, `a18`, `a19`, `a20`, `a21`, `a22`, `a23`, `a24`, `a25`, `a26`, `a27`, `a28`, `a29`, `a30`, `a31`, `a32`, `a33`, `a34`, `a35`, `a36`, `a37`, `a38`, `a39`, `a40`, `a41`, `a42`, `a43`, `a44`, `a45`, `a46`, `a47`, `a48`, `a49`, `a50`) VALUES
(1, 1, '1', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'JO', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `assi`
--
ALTER TABLE `assi`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `assi1`
--
ALTER TABLE `assi1`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cls`
--
ALTER TABLE `cls`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `exam`
--
ALTER TABLE `exam`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `material`
--
ALTER TABLE `material`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `question1`
--
ALTER TABLE `question1`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `result`
--
ALTER TABLE `result`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `student`
--
ALTER TABLE `student`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `uques`
--
ALTER TABLE `uques`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `assi`
--
ALTER TABLE `assi`
  MODIFY `id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `assi1`
--
ALTER TABLE `assi1`
  MODIFY `id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=38;

--
-- AUTO_INCREMENT for table `cls`
--
ALTER TABLE `cls`
  MODIFY `id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `exam`
--
ALTER TABLE `exam`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `material`
--
ALTER TABLE `material`
  MODIFY `id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `question1`
--
ALTER TABLE `question1`
  MODIFY `id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;

--
-- AUTO_INCREMENT for table `result`
--
ALTER TABLE `result`
  MODIFY `id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `student`
--
ALTER TABLE `student`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `uques`
--
ALTER TABLE `uques`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
